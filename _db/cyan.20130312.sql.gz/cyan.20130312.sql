-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Värd: localhost
-- Skapad: 12 mars 2013 kl 22:46
-- Serverversion: 5.5.9
-- PHP-version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databas: `cyan`
--

-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_access`
--

CREATE TABLE `cyan_access` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_access`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_apikeys`
--

CREATE TABLE `cyan_apikeys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_apikeys`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_comments`
--

CREATE TABLE `cyan_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) NOT NULL,
  `comment` text NOT NULL,
  `time` datetime NOT NULL,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_content` (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Data i tabell `cyan_comments`
--

INSERT INTO `cyan_comments` VALUES(1, 5, 'Testar!', '0000-00-00 00:00:00', 'Anders', 'anders@bobolo.se');
INSERT INTO `cyan_comments` VALUES(2, 5, 'Testar!', '0000-00-00 00:00:00', 'Anders', 'anders@bobolo.se');
INSERT INTO `cyan_comments` VALUES(3, 5, 'WEeeho!', '0000-00-00 00:00:00', 'Kalle Balle', '');
INSERT INTO `cyan_comments` VALUES(4, 5, 'Kommentar!', '0000-00-00 00:00:00', 'Namn', 'Epost');
INSERT INTO `cyan_comments` VALUES(5, 0, 'Testar', '0000-00-00 00:00:00', 'Orvar', 'anders@bobolo.se');
INSERT INTO `cyan_comments` VALUES(6, 0, 'Testar', '0000-00-00 00:00:00', 'Orvar', 'anders@bobolo.se');
INSERT INTO `cyan_comments` VALUES(7, 0, 'TEstaar', '0000-00-00 00:00:00', 'Orvar', 'anders@bobolo.se');
INSERT INTO `cyan_comments` VALUES(8, 0, 'TEstaar', '0000-00-00 00:00:00', 'Orvar', 'anders@bobolo.se');
INSERT INTO `cyan_comments` VALUES(9, 0, 'asdf', '0000-00-00 00:00:00', 'asdf', 'asdf');
INSERT INTO `cyan_comments` VALUES(10, 103, 'qsadfv', '0000-00-00 00:00:00', 'asdf', '234');
INSERT INTO `cyan_comments` VALUES(11, 103, 'asf', '2013-01-20 16:28:00', 'asdf', 'asdf');
INSERT INTO `cyan_comments` VALUES(12, 103, '234234', '2013-01-20 16:28:32', 'Kalle', 'asdf');
INSERT INTO `cyan_comments` VALUES(13, 103, 'sadfasdf', '2013-01-20 17:35:08', 'Herr Ljungberg', '');

-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_content_terms`
--

CREATE TABLE `cyan_content_terms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) unsigned DEFAULT NULL,
  `term_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_content_id` (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_content_terms`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_fields`
--

CREATE TABLE `cyan_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `description` text,
  `type` varchar(50) NOT NULL,
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_fields`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_options`
--

CREATE TABLE `cyan_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `option_name` varchar(255) NOT NULL,
  `option_value` text,
  `autoload` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Data i tabell `cyan_options`
--

INSERT INTO `cyan_options` VALUES(1, 0, 'time_zone', 'CET', 1);
INSERT INTO `cyan_options` VALUES(2, 0, 'site_url', 'http://localhost/kohana-project/', 1);
INSERT INTO `cyan_options` VALUES(3, 0, 'site_name', 'Kohana Project!', 1);
INSERT INTO `cyan_options` VALUES(4, 0, 'fouxxx', 'test223', 0);
INSERT INTO `cyan_options` VALUES(5, 0, 'language', 'en-us', 0);
INSERT INTO `cyan_options` VALUES(6, 0, 'en till', 'hej!', 0);
INSERT INTO `cyan_options` VALUES(7, 0, 'testar2', 'testar2', 0);
INSERT INTO `cyan_options` VALUES(8, 0, 'igen2', 'en sak2', 0);
INSERT INTO `cyan_options` VALUES(9, 0, 'Ny option', 'test', 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_posts`
--

CREATE TABLE `cyan_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(25) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime DEFAULT NULL,
  `testar` varchar(100) DEFAULT NULL,
  `author` int(10) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `canonical_url` varchar(255) DEFAULT NULL,
  `mime_type` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `meta` text,
  `color` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `star` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `site_id` tinyint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=160 ;

--
-- Data i tabell `cyan_posts`
--

INSERT INTO `cyan_posts` VALUES(115, 0, '1', '2013-01-29 08:15:57', '2013-02-28 08:15:52', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(116, 0, '1', '2013-01-29 08:18:30', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(117, 0, '1', '2013-01-29 08:20:41', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(118, 0, '1', '2013-01-29 08:21:26', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(119, 0, '1', '2013-01-29 08:21:46', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(120, 0, '13', '2013-01-29 08:22:31', '2013-01-30 08:34:36', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(121, 0, '20', '2013-01-29 08:23:50', '2013-01-29 08:31:50', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(122, 0, '1', '2013-01-29 08:32:17', '2013-02-15 08:26:29', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(123, 0, '17', '2013-01-29 08:33:34', '2013-01-29 08:33:48', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(124, 0, '7', '2013-01-29 08:36:04', '2013-01-29 08:36:23', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(125, 0, '3', '2013-01-30 08:32:15', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(126, 0, '13', '2013-01-30 08:33:25', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(127, 0, '7', '2013-01-30 08:35:07', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(128, 0, '18', '2013-01-30 08:36:18', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(129, 0, '18', '2013-01-30 08:37:29', '2013-01-30 08:37:41', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(130, 0, '1', '2013-01-31 21:31:40', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(131, 0, '1', '2013-02-01 06:19:51', '2013-02-01 06:19:57', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(132, 0, '1', '2013-02-01 18:56:31', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(133, 0, '1', '2013-02-01 18:56:45', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(134, 0, '1', '2013-02-01 18:56:53', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(135, 0, '6', '2013-02-01 18:57:03', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(136, 0, '3', '2013-02-02 16:13:26', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(137, 0, '13', '2013-02-02 20:11:45', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(138, 0, '6', '2013-02-03 20:29:02', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(139, 0, '1', '2013-02-04 08:07:46', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(140, 0, '19', '2013-02-04 08:08:11', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(141, 0, '19', '2013-02-04 08:08:22', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(142, 0, '7', '2013-02-04 22:13:29', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(143, 0, '7', '2013-02-04 22:13:46', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(144, 0, '3', '2013-02-04 22:14:04', '2013-02-04 22:14:12', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(145, 0, '13', '2013-02-04 22:14:44', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(146, 0, '6', '2013-02-04 22:15:15', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(147, 0, '21', '2013-02-05 08:25:23', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(148, 0, '21', '2013-02-05 08:29:15', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(149, 0, '17', '2013-02-05 08:35:01', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(150, 0, '21', '2013-02-05 08:35:21', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(151, 0, '7', '2013-02-05 08:37:06', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(152, 0, '13', '2013-02-06 16:59:07', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(153, 0, '6', '2013-02-06 16:59:56', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(154, 0, '1', '2013-02-16 11:17:39', '2013-02-16 11:18:18', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(155, 0, '13', '2013-02-16 13:38:27', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(156, 0, '28', '2013-02-21 08:50:41', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(157, 0, '17', '2013-02-25 21:21:13', NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(158, 0, '25', '2013-02-27 21:06:31', '2013-02-27 21:06:38', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_posts` VALUES(159, 0, '22', '2013-03-12 22:45:51', NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_post_data`
--

CREATE TABLE `cyan_post_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `language` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `status` varchar(20) DEFAULT NULL,
  `revision` tinyint(5) unsigned NOT NULL DEFAULT '1',
  `state` varchar(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `excerpt` text,
  `content` mediumtext,
  `created_date` datetime DEFAULT NULL,
  `author` int(10) unsigned NOT NULL,
  `modified_date` datetime DEFAULT NULL,
  `modified_by` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_content_language_status` (`post_id`,`language`,`status`),
  KEY `fk_post_id` (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

--
-- Data i tabell `cyan_post_data`
--

INSERT INTO `cyan_post_data` VALUES(3, 115, 1, NULL, 1, NULL, 'Idag är det onsdag22', 'idag ar det onsdag22', NULL, '<p>Neque ligula neque libero lorem ante vestibulum suscipit. Integer donec nulla ante libero pretium arcu non leo. Ligula maecenas interdum ut vel porta eget dolor eleifend non ut nec. Etiam urna justo non ligula turpis massa elit hendrerit imperdiet adipiscing? Turpis donec sed non cras gravida eget tincidunt lacus curabitur sit rutrum. Sagittis non sed est nisi. Bibendum aliquam faucibus sociis urna phasellus lectus nunc. Elementum libero mauris gravida nec urna. Ligula curabitur vitae in lorem amet ut dui condimentum urna volutpat. Risus sapien nec leo lacus ut nisi sed sed purus. Ligula nulla varius consectetur eros fermentum eget mollis sagittis vitae rutrum venenatis?</p>\n\n<p>Eu massa risus sed mauris est eget sollicitudin viverra quis donec. Nullam nulla facilisis risus cursus montes pellentesque cum consectetur est. Id sit vestibulum erat erat est laoreet justo pretium non integer: Nisi amet luctus porttitor donec porttitor donec? Interdum ut dignissim pharetra fermentum at. Sagittis consectetur donec dolor commodo metus interdum a non. Vel lectus blandit hendrerit eget non pellentesque egestas, Orci aenean odio posuere vestibulum turpis suspendisse donec varius augue arcu. Enim libero adipiscing rutrum non risus pharetra sagittis curabitur eu nam. Convallis aliquam cursus ligula sodales:</p>\n\n<p>A in interdum posuere iaculis est est erat: Vestibulum amet sed ridiculus sem vitae metus? Malesuada cras sociis nulla mauris ut eget accumsan nunc viverra. Eros diam turpis bibendum natoque fringilla sed nam ligula sed dignissim eget. Malesuada penatibus suscipit sit viverra tristique vitae hendrerit tortor. Tincidunt pellentesque quis integer pharetra et nec sed metus. Ligula vel eget urna neque a erat varius. Morbi id leo mattis cras turpis; Pellentesque cras cursus integer elit suscipit nascetur venenatis. Lacinia ultricies nec nulla pellentesque ut aliquam libero quam. Lacinia eget hendrerit ligula arcu rutrum neque phasellus quis rutrum in et? Mollis enim turpis vestibulum vitae sodales lacus mollis. Rutrum cras augue lacus eget volutpat ipsum:</p>\n\n<p>Egestas neque a adipiscing sodales in sed sapien orci, Nisi nec venenatis consectetur lectus risus massa rhoncus placerat eget mollis egestas, Risus sociis dui nam pulvinar luctus non porta ante sodales. Tempor porta dui dui lorem sed aliquam lectus rhoncus? Nisl bibendum eros egestas turpis lectus cursus ipsum; Dolor nulla dui a eleifend ridiculus eros? Lacus magna ipsum lobortis justo nulla euismod sed ligula sem,</p>\n\n<p>Bibendum quis etiam tellus bibendum lorem lorem nulla sed ut vitae; Non nisl venenatis bibendum aliquam placerat felis amet sodales. Non dis nisi cras eleifend consequat. Dignissim at sagittis lacus dictum augue: Cras justo duis lacinia curabitur hendrerit non eu dolor. Etiam massa mauris id sociis vitae luctus nunc dignissim pretium; Phasellus nisl donec nulla quis tincidunt aenean neque elementum sapien vel. Ut neque consectetur ligula augue fusce neque non eleifend. Eget condimentum sodales adipiscing iaculis eros arcu porta? Justo eros rutrum erat facilisis varius dolor, Ante nascetur nulla eget morbi ut sed pharetra malesuada euismod. Donec aenean natoque fusce sed sapien commodo purus erat? Nisl ridiculus leo pulvinar blandit in odio mauris sit ut. At dictum aliquam sollicitudin bibendum in</p>\n', '2013-01-29 08:15:57', 1, '2013-02-28 08:15:52', 0);
INSERT INTO `cyan_post_data` VALUES(4, 116, 1, NULL, 1, NULL, 'AAbaaa', 'aabaaa', NULL, '<p>apa</p>\n', '2013-01-29 08:18:30', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(5, 117, 1, NULL, 1, NULL, 'Album 2', 'album 2', NULL, '<p><strong>Detta</strong> &auml;r ett album!</p>\n\n<h1>Yeah!</h1>\n', '2013-01-29 08:20:41', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(6, 118, 1, NULL, 1, NULL, 'Fraggel??', 'fraggel', NULL, '<p>Denna skall vara p&aring; fraggel...</p>\n', '2013-01-29 08:21:26', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(7, 119, 1, NULL, 1, NULL, 'Fraggel??', 'fraggel', NULL, '<p>Denna skall vara p&aring; fraggel...</p>\n', '2013-01-29 08:21:46', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(8, 120, 1, NULL, 1, NULL, 'Yes, nu skall du väl bara fixa en sak till...', 'yes nu skall du val bara fixa en sak till', NULL, '<h2>Ut lorem, pretium tellus erat porta adipiscing lacus</h2>\n\n<p>Vitae augue eget porta neque volutpat metus in pellentesque at. Lobortis faucibus pharetra montes dolor justo dolor facilisis hendrerit rhoncus mauris; Vitae enim nunc ante semper neque. Sodales consectetur cursus pharetra phasellus vestibulum cursus nisl lorem maecenas? Vivamus justo commodo eleifend donec iaculis sodales mi vitae.Vivamus justo commodo eleifend donec iaculis sodales mi vitae.&nbsp;<a href="http://lorem.bobolo.se/#">Vivamus justo commodo eleifend donec iaculis sodales mi vitae.&nbsp;Vivamus justo commodo eleifend donec iaculis sodales mi vitae.&nbsp;</a>Nec convallis vitae tellus metus sed quis eu cras eu. Pretium vitae mi elementum vestibulum lectus mauris lacus sapien aenean. Interdum aliquam est placerat augue. Elementum mus nulla vel ligula enim!&nbsp;<a href="http://lorem.bobolo.se/#">Elementum mus nulla vel ligula enim!&nbsp;</a>Facilisis dignissim luctus tristique a phasellus velit donec mauris velit vivamus non. Rhoncus mattis sed lorem tristique erat id. Pretium tincidunt felis non sed: Sollicitudin rutrum fusce tempor ut lectus neque enim curabitur aliquam.&nbsp;Sollicitudin rutrum fusce tempor ut lectus neque enim curabitur aliquam.&nbsp;Nibh dapibus vivamus sed at risus urna lacus! Bibendum iaculis dapibus volutpat rutrum vitae aenean cras sed. Integer risus eget eget sapien eget risus volutpat vitae duis: In ipsum eu dolor consequat porta erat massa nunc mollis eu:&nbsp;In ipsum eu dolor consequat porta erat massa nunc mollis eu:</p>\n\n<ul>\n	<li>Dui aliquam mauris risus curabitur bibendum semper libero at. Mauris libero dis risus ipsum nec arcu aliquam tincidunt natoque. Vivamus a pretium et quis ut nulla fusce eget. Sociis eget risus sem arcu nunc pretium eleifend! Tristique ligula gravida erat odio dictum sodales.</li>\n	<li>Donec risus sodales velit dui porta nunc vitae. Sociis malesuada tincidunt quisque nisl rhoncus dui malesuada eros sodales. Ridiculus ultrices accumsan nulla blandit donec vestibulum nisl sed consequat hendrerit sed? Proin metus vel porta mauris aenean sit luctus fermentum eget tincidunt blandit. Venenatis nulla molestie mauris ipsum nec; Integer cras ligula amet tincidunt sodales leo a donec fermentum phasellus.</li>\n	<li>Odio ut ac nam pharetra porta. Vitae non quam justo porta nulla feugiat at. Volutpat porta volutpat volutpat pulvinar vivamus tellus euismod sed convallis nec; Adipiscing id ac dis lorem quis cursus nisi quis a nunc dignissim, Leo phasellus elit nulla aliquam semper at dui consectetur amet diam.</li>\n</ul>\n\n<p>Sodales leo pellentesque egestas aenean risus.&nbsp;Sodales leo pellentesque egestas aenean risus.&nbsp;Eget eros lacus facilisis adipiscing? Aliquam mauris lacinia quis venenatis neque placerat arcu; Ipsum sodales curabitur nam ut enim, Purus mauris nunc donec vitae et vitae: Volutpat arcu lorem non ligula nec enim? Est nulla ridiculus luctus non mauris porta justo porttitor risus! Arcu ipsum sed lacus ipsum dolor vitae a? Odio varius magna facilisis laoreet: Erat a placerat ultricies erat non? Vestibulum pellentesque in hendrerit id a nulla pellentesque sapien hendrerit libero; Facilisis quis in amet fermentum ac vestibulum. Ligula odio sapien gravida sed duis lacus; Curabitur metus amet lectus amet erat ut eget urna suspendisse.&nbsp;<a href="http://lorem.bobolo.se/#">Curabitur metus amet lectus amet erat ut eget urna suspendisse.&nbsp;</a>Vestibulum mattis risus sapien consequat donec pellentesque sit amet nulla diam? Cum non integer vel justo eleifend tincidunt! Id sit dui lacinia lectus enim porta fermentum eget gravida? Sit parturient placerat eros libero egestas dolor erat amet vestibulum luctus donec,&nbsp;Sit parturient placerat eros libero egestas dolor erat amet vestibulum luctus donec,&nbsp;Dui arcu integer ridiculus aliquam pellentesque massa interdum ultrices non. Pellentesque iaculis ut nec quam sagittis elit proin sodales consequat in turpis!&nbsp;Pellentesque iaculis ut nec quam sagittis elit proin sodales consequat in turpis!</p>\n\n<blockquote>\n<p>Fusce turpis tortor lorem dis ut sed et consectetur. Nisl consectetur sit eu risus: Sapien porta tristique eu bibendum lectus nec est risus nam risus egestas. Sapien porta tristique eu bibendum lectus nec est risus nam risus egestas. Elementum vitae a aliquam sem vitae dolor porta justo vestibulum risus id.</p>\n</blockquote>\n\n<p>Tincidunt urna malesuada cum hendrerit ligula dui pretium at risus duis! Non gravida vel non amet. Pretium sed egestas tempor mattis ligula odio vivamus dui urna. Placerat luctus turpis eros cursus dolor fermentum? Duis blandit fermentum consectetur sapien pretium dolor: Mauris porta vestibulum consectetur lacus; Augue vitae tincidunt in facilisis pretium consectetur urna porttitor!&nbsp;Augue vitae tincidunt in facilisis pretium consectetur urna porttitor!&nbsp;Erat erat nec sem vivamus risus est interdum? Quis ultrices turpis volutpat velit risus sapien ligula augue pulvinar lacinia nec. Sollicitudin volutpat dolor suspendisse eget. Justo risus sem nam pharetra viverra risus enim id. Eu felis odio ut elementum blandit dignissim mus quam est eget risus. Turpis volutpat a aliquet sed cras erat aenean eget pretium quisque, Lacinia sed consectetur id vestibulum nec accumsan phasellus donec: Ut adipiscing morbi sit dui nullam ut sed non nec. Iaculis porta gravida urna leo dui dis neque non nec eleifend eget. Nullam pulvinar facilisis bibendum elit nibh mauris: Vestibulum tincidunt malesuada gravida nec lacus fringilla gravida nec blandit congue!&nbsp;Vestibulum tincidunt malesuada gravida nec lacus fringilla gravida nec blandit congue!Purus lorem dolor massa dis rutrum. Dui vestibulum est in justo fusce tincidunt nec et ligula mauris.</p>\n\n<p>Cursus vel feugiat tincidunt placerat. Sit neque lorem elit ipsum odio ligula gravida leo tellus;&nbsp;<a href="http://lorem.bobolo.se/#">Sit neque lorem elit ipsum odio ligula gravida leo tellus;&nbsp;</a>Aliquam volutpat augue nisl lacus metus, Eu amet sodales dis placerat quis lacus tincidunt?&nbsp;<a href="http://lorem.bobolo.se/#">Eu amet sodales dis placerat quis lacus tincidunt?&nbsp;</a>Eget non risus a bibendum risus fermentum vivamus aliquam aenean. Cursus neque venenatis ipsum nec nisi cras sed volutpat metus. At nisl consequat dolor eu eget justo non pretium! Quis neque facilisis in eget? Lobortis est nisl ullamcorper nunc cursus convallis quisque eleifend porta:&nbsp;Lobortis est nisl ullamcorper nunc cursus convallis quisque eleifend porta:&nbsp;Massa cum eget etiam elementum eget. Eros non lacus facilisis enim magnis sollicitudin sed iaculis volutpat in integer. Sodales dolor consectetur iaculis facilisis amet facilisis bibendum consectetur quam? Suscipit nunc parturient quam nunc; Nunc phasellus nulla pulvinar ipsum; Tristique faucibus fermentum bibendum rhoncus luctus pharetra interdum eu consectetur!</p>\n\n<p>Nisl dolor lectus arcu at donec bibendum nec sit rutrum: Eget velit ut viverra bibendum ac risus tincidunt venenatis. Nec cras ut urna cursus nunc proin mollis sodales sodales urna nisl. Convallis lectus orci sapien leo. Non blandit nunc aenean mauris hendrerit posuere enim. Donec sit tristique venenatis suscipit curabitur risus nibh leo nec metus maecenas. Auctor porttitor nisl nulla mi bibendum arcu! Aliquet turpis pellentesque varius quis varius at gravida. Neque quam euismod tristique nisi odio est lectus nascetur:Neque quam euismod tristique nisi odio est lectus nascetur:&nbsp;Gravida phasellus amet hendrerit justo tortor nisi facilisis dolor pellentesque nibh; Erat cras nisi venenatis semper consectetur aliquam imperdiet arcu ut turpis tempor. Phasellus nibh eu sed donec lacus fermentum lorem sagittis phasellus fermentum sapien. Nisl eget leo porta urna suscipit cum dapibus ipsum; Facilisis vitae vestibulum pretium risus mollis urna eu a? Ridiculus facilisis a egestas mauris convallis lacinia mauris; Dignissim nulla congue nec viverra. Montes sed mollis erat dolor nam dictum risus nulla aliquam nam. Eu gravida pharetra nec dui. Convallis aliquet iaculis massa ultrices quam luctus augue neque pellentesque cum eu.</p>\n', '2013-01-29 08:22:31', 1, '2013-01-30 08:34:36', 0);
INSERT INTO `cyan_post_data` VALUES(9, 121, 1, NULL, 1, NULL, 'Första zombietypen', 'forsta zombietypen', NULL, '<h2><strong>F&ouml;rsta zombietypen</strong></h2>\n\n<p>Sed non vitae vel sociis iaculis rutrum montes, Id bibendum tempor phasellus ligula nec enim turpis! Cursus eros nam condimentum condimentum risus: Donec vitae fermentum natoque sed elit consequat non nec libero morbi sed. Risus nec vitae erat lorem nibh aliquam cursus non ultricies ridiculus facilisis; Leo sollicitudin sed nibh dictum risus fusce fermentum non aliquam. Commodo non massa erat lorem eu blandit, Ultricies non eu lacus at: Eget nisi commodo ullamcorper tincidunt at enim turpis mus, Aenean augue at dolor sem arcu eget commodo feugiat sollicitudin donec vitae.</p>\n\n<p>Ac facilisis nulla ut sem venenatis sit ridiculus eros; Gravida erat lectus ante feugiat arcu! Consequat neque vel sollicitudin dapibus interdum dignissim sodales massa sit; Phasellus eget nunc dui eu non dolor cras integer dui, Risus hendrerit arcu nunc gravida enim; Aliquam gravida nibh ipsum mollis aliquet tincidunt ultrices augue. Morbi et mauris erat cursus et nunc sollicitudin! Consectetur amet turpis integer semper risus aliquet diam. Tincidunt nisl at sodales at eget nisi turpis sit at etiam. Ut nibh volutpat ut cursus. Amet justo tristique ante ultricies arcu cras non leo sem. Placerat maecenas penatibus sem volutpat et non dignissim fermentum rutrum consequat; Consectetur non consequat mauris lorem dolor dapibus egestas amet. Romani ite domum.</p>\n\n<p>Montes semper hendrerit amet dui augue eget sodales risus magnis augue! Suspendisse est pulvinar eu ante volutpat. Eu gravida dolor lacinia purus ligula suscipit elementum pharetra malesuada in duis: Dolor eros tincidunt sed urna lacus odio non imperdiet pretium. Diam pretium turpis dis accumsan, Venenatis dui ridiculus massa risus aenean donec ut venenatis. Iaculis vel erat consequat pretium vel blandit eu eu; Accumsan in id eu massa nec ligula?</p>\n\n<p>Mollis erat cras convallis vitae posuere mauris: Eu ullamcorper vitae cum ut nec placerat consectetur! Varius turpis odio nunc parturient phasellus, In phasellus est tincidunt accumsan amet. Non phasellus porta sem non nisi proin posuere aliquet nullam magnis? Mauris non penatibus eu interdum sodales venenatis lacus aenean gravida gravida non. Tincidunt orci sed eu neque congue eu metus eget in condimentum at,</p>\n\n<p>Neque vel nunc est congue commodo risus duis ut auctor vivamus aenean! Et facilisis vitae fusce dolor tincidunt. Nisi sit malesuada id porta, Sapien tortor dolor lorem nec? Massa tristique orci lorem urna nisi et cursus. Pharetra risus semper ultrices turpis mi! Donec accumsan suscipit facilisis porta at. Nec id in nec in pretium lectus donec</p>\n', '2013-01-29 08:23:50', 1, '2013-01-29 08:31:50', 0);
INSERT INTO `cyan_post_data` VALUES(10, 122, 1, NULL, 1, NULL, 'Apa2', 'apa2', NULL, '<div id="lorem" style="font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; line-height: 20px; background-color: rgb(245, 243, 239);">\n<p style="margin: 0px 0px 10px;">Sed non vitae vel sociis iaculis rutrum montes, Id bibendum tempor phasellus ligula nec enim turpis! Cursus eros nam condimentum condimentum risus: Donec vitae fermentum natoque sed elit consequat non nec libero morbi sed. Risus nec vitae erat lorem nibh aliquam cursus non ultricies ridiculus facilisis; Leo sollicitudin sed nibh dictum risus fusce fermentum non aliquam. Commodo non massa erat lorem eu blandit, Ultricies non eu lacus at: Eget nisi commodo ullamcorper tincidunt at enim turpis mus, Aenean augue at dolor sem arcu eget commodo feugiat sollicitudin donec vitae.</p>\n\n<p style="margin: 0px 0px 10px;">Ac facilisis nulla ut sem venenatis sit ridiculus eros; Gravida erat lectus ante feugiat arcu! Consequat neque vel sollicitudin dapibus interdum dignissim sodales massa sit; Phasellus eget nunc dui eu non dolor cras integer dui, Risus hendrerit arcu nunc gravida enim; Aliquam gravida nibh ipsum mollis aliquet tincidunt ultrices augue. Morbi et mauris erat cursus et nunc sollicitudin! Consectetur amet turpis integer semper risus aliquet diam. Tincidunt nisl at sodales at eget nisi turpis sit at etiam. Ut nibh volutpat ut cursus. Amet justo tristique ante ultricies arcu cras non leo sem. Placerat maecenas penatibus sem volutpat et non dignissim fermentum rutrum consequat; Consectetur non consequat mauris lorem dolor dapibus egestas amet. Romani ite domum.</p>\n\n<p style="margin: 0px 0px 10px;">Montes semper hendrerit amet dui augue eget sodales risus magnis augue! Suspendisse est pulvinar eu ante volutpat. Eu gravida dolor lacinia purus ligula suscipit elementum pharetra malesuada in duis: Dolor eros tincidunt sed urna lacus odio non imperdiet pretium. Diam pretium turpis dis accumsan, Venenatis dui ridiculus massa risus aenean donec ut venenatis. Iaculis vel erat consequat pretium vel blandit eu eu; Accumsan in id eu massa nec ligula?</p>\n\n<p style="margin: 0px 0px 10px;">Mollis erat cras convallis vitae posuere mauris: Eu ullamcorper vitae cum ut nec placerat consectetur! Varius turpis odio nunc parturient phasellus, In phasellus est tincidunt accumsan amet. Non phasellus porta sem non nisi proin posuere aliquet nullam magnis? Mauris non penatibus eu interdum sodales venenatis lacus aenean gravida gravida non. Tincidunt orci sed eu neque congue eu metus eget in condimentum at,</p>\n\n<p style="margin: 0px 0px 10px;">Neque vel nunc est congue commodo risus duis ut auctor vivamus aenean! Et facilisis vitae fusce dolor tincidunt. Nisi sit malesuada id porta, Sapien tortor dolor lorem nec? Massa tristique orci lorem urna nisi et cursus. Pharetra risus semper ultrices turpis mi! Donec accumsan suscipit facilisis porta at. Nec id in nec in pretium lectus donec.</p>\n\n<div>&nbsp;</div>\n</div>\n', '2013-01-29 08:32:17', 1, '2013-02-15 08:26:29', 0);
INSERT INTO `cyan_post_data` VALUES(11, 123, 1, NULL, 1, NULL, '汉语/漢語 Hànyǔ, 华语/華語 Huáyǔ, or 中文 Zhōngwén', 'hany huay or zhongwen', NULL, '<p><span style="color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: small; line-height: 16px;">汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n,&nbsp;汉语/漢語 H&agrave;nyǔ,<strong> 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, </strong>华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n汉语/漢語 H&agrave;nyǔ, 华语/華語 Hu&aacute;yǔ, or 中文 Zhōngw&eacute;n</span></p>\n', '2013-01-29 08:33:34', 1, '2013-01-29 08:33:48', 0);
INSERT INTO `cyan_post_data` VALUES(12, 124, 1, NULL, 1, NULL, '华语/華語 FOUX! (kapitsch!)', 'foux kapitsch', NULL, '<p>华语/華語 FOUX boi! Boyakka!</p>\n', '2013-01-29 08:36:04', 1, '2013-01-29 08:36:23', 0);
INSERT INTO `cyan_post_data` VALUES(13, 125, 1, NULL, 1, NULL, 'En på musik', 'en pa musik', NULL, '<h2>Lorem, nascetur vestibulum quis ante, ultrices dui dignissim,</h2>\n\n<p>Magnis tincidunt dolor augue eget ac sollicitudin a neque quam! Odio metus leo gravida enim tristique vestibulum: Aliquet dui tincidunt lorem quis etiam nulla semper ligula nec! Enim nibh vivamus eu risus pharetra. Vivamus justo elementum tincidunt hendrerit porta adipiscing: Aenean enim sagittis vestibulum eu neque elit pharetra non placerat nisl pharetra. Amet metus turpis lacus est proin erat etiam; Tempor mauris laoreet nec justo morbi aenean dictum duis vestibulum rutrum: Euismod cras a sodales donec lectus elementum cursus sagittis lectus nunc. Metus nulla diam porta quisque nascetur vitae lorem sapien erat. Nulla suscipit eu natoque sed eget vivamus fringilla erat varius.&nbsp;Nulla suscipit eu natoque sed eget vivamus fringilla erat varius.&nbsp;Turpis volutpat hendrerit nunc ligula sit bibendum duis. Dui feugiat vel dui eget eu tempor sed interdum penatibus. Parturient imperdiet sed sed sagittis phasellus in non massa leo,</p>\n\n<h2>Luctus sit varius erat non sit urna risus</h2>\n\n<ol>\n	<li>Dignissim pellentesque quis nisl phasellus suscipit porta rhoncus phasellus erat at lacinia,&nbsp;Dignissim pellentesque quis nisl phasellus suscipit porta rhoncus phasellus erat at lacinia,&nbsp;Vitae nec arcu eget dignissim natoque semper justo neque non pharetra tempor. Tincidunt blandit euismod donec mauris? Congue interdum risus imperdiet nullam ipsum massa porta volutpat in sem ligula! Faucibus enim sagittis odio adipiscing malesuada id. Euismod libero nec porta porta commodo adipiscing vitae convallis.Euismod libero nec porta porta commodo adipiscing vitae convallis.</li>\n	<li>Dui tincidunt facilisis metus imperdiet cras fermentum faucibus sit odio. Eget augue amet erat mauris odio risus: Curabitur sodales sapien donec libero eu enim sit dui eu! Dignissim consequat eget lorem congue at vitae odio velit lacus. In a ipsum blandit non eget leo, Venenatis luctus eget a urna vestibulum fermentum odio purus nisi aliquam.</li>\n	<li>In placerat pharetra eleifend venenatis maecenas amet tortor pellentesque venenatis ipsum aenean; Id leo ligula porta nulla. Elit pharetra interdum vehicula ut leo mauris pharetra:&nbsp;Elit pharetra interdum vehicula ut leo mauris pharetra:&nbsp;Proin dolor augue mauris purus molestie libero lectus aliquam vitae vel. Eget risus risus lobortis vitae porta vitae ridiculus dolor nulla mattis! Pharetra non non volutpat magna rutrum dignissim dolor,</li>\n	<li>Felis sed enim leo pretium ullamcorper egestas eget justo non malesuada quis: Mi a ut nulla sit non nisl nibh gravida: Non lectus ligula aliquet porta orci ut lectus turpis aliquam porta pulvinar. Ante ultrices a aliquet nisl eu viverra lacus nulla;</li>\n	<li>Facilisis rutrum integer ut venenatis amet eu est curabitur non. Eleifend dignissim lacus natoque bibendum gravida quam lorem.&nbsp;<a href="http://lorem.bobolo.se/#">Eleifend dignissim lacus natoque bibendum gravida quam lorem.&nbsp;</a>Quis interdum lacus a est proin sed ultrices eget. Leo felis mollis metus ipsum purus porta non convallis lacus non ipsum. Laoreet sed eget pulvinar nec eget cras at non. Cursus et vestibulum eget risus massa:</li>\n</ol>\n\n<p>Neque risus augue mattis montes dapibus at: Nunc pretium fermentum porta dolor. Eu varius mauris eu aenean eu: In blandit pellentesque tincidunt sem malesuada diam amet ut. Metus orci pretium elementum at diam vitae cras metus convallis cras vel. Ligula arcu eget sed hendrerit enim amet metus nisl sit, Pellentesque fermentum vivamus arcu dignissim tellus metus. Vitae rhoncus sagittis leo lobortis hendrerit justo laoreet felis! Pretium convallis velit consectetur tincidunt venenatis! Porttitor amet turpis odio lacinia:Porttitor amet turpis odio lacinia:&nbsp;Non tortor nulla diam ante vitae bibendum porta eu lacus aenean. Laoreet sociis urna amet tincidunt neque blandit.&nbsp;Laoreet sociis urna amet tincidunt neque blandit.&nbsp;Quis interdum eget nullam viverra fusce bibendum risus. Luctus lacus porta sapien nec lacus curabitur non nullam bibendum placerat accumsan:Luctus lacus porta sapien nec lacus curabitur non nullam bibendum placerat accumsan:&nbsp;Vehicula sed non quis mi aliquam id ultrices amet:</p>\n\n<h2>Gravida urna, auctor eu neque sodales, parturient</h2>\n\n<blockquote>\n<p>Aenean montes nunc augue fermentum: Proin amet diam neque dui massa euismod. At luctus vivamus dui sed! Nunc nunc turpis ut est sodales urna? Sed vehicula rhoncus amet ligula lacus. Dictum venenatis ante pretium porta donec nulla nam ipsum et. Sed risus fringilla convallis et! Purus nulla semper rutrum nam sollicitudin non. Purus nulla semper rutrum nam sollicitudin non.</p>\n</blockquote>\n\n<p>Egestas sit tristique urna phasellus a eget cursus nisi dignissim dolor! Est quis nunc eros quis, Sodales sed nisi vitae dui elit consectetur, Sit sagittis dui proin porttitor sit tincidunt. Eget dolor fermentum bibendum vitae penatibus tortor amet sed: Et at penatibus ullamcorper urna diam velit eros aenean, Imperdiet sed tincidunt sagittis dui sagittis. Gravida gravida vel nibh dui metus pellentesque metus, Bibendum cras semper risus nec nibh ullamcorper nec. Donec non aliquam dolor imperdiet amet vitae eros ut. Sed hendrerit congue nec sodales ligula risus urna quis curabitur gravida ultrices. Nec eu eget ligula id pellentesque placerat nisl sodales erat est:</p>\n\n<p>Dui euismod orci placerat risus lacus commodo. At volutpat neque porttitor eu integer at ligula vel libero libero cursus? Accumsan adipiscing congue augue neque nec risus eget amet pretium at. Curabitur ut sagittis mauris elit. Donec imperdiet bibendum elit pretium neque neque; Neque erat ultrices sodales viverra mi erat nec aliquam euismod donec nisl.&nbsp;<a href="http://lorem.bobolo.se/#">Neque erat ultrices sodales viverra mi erat nec aliquam euismod donec nisl.&nbsp;</a>Urna aliquam consectetur at in risus et nulla mauris non, Sodales mattis vitae nec tortor sagittis vivamus nec a risus risus nulla: Sit phasellus tristique turpis posuere egestas; Vel tincidunt libero cursus congue! Gravida lacus proin vestibulum nunc.&nbsp;Gravida lacus proin vestibulum nunc.&nbsp;Cursus hendrerit sapien iaculis justo phasellus pellentesque sem;&nbsp;<a href="http://lorem.bobolo.se/#">Cursus hendrerit sapien iaculis justo phasellus pellentesque sem;&nbsp;</a>Suscipit urna metus et euismod dolor lorem!&nbsp;<a href="http://lorem.bobolo.se/#">Suscipit urna metus et euismod dolor lorem!&nbsp;</a>Pellentesque rhoncus at gravida risus amet tristique id quisque venenatis sit. Placerat vitae pharetra dolor tempor.&nbsp;Placerat vitae pharetra dolor tempor.&nbsp;Dignissim sit lacus a facilisis id turpis sit urna vel dolor etiam. Magna euismod ut erat venenatis justo. Sem neque vitae sed viverra non eleifend integer non.</p>\n\n<h2>Commodo consectetur ut elit bibendum</h2>\n\n<p>Pellentesque porta congue arcu neque vitae nulla bibendum non vel egestas dictum. At non cras sagittis risus euismod?&nbsp;<a href="http://lorem.bobolo.se/#">At non cras sagittis risus euismod?&nbsp;</a>Sapien cras erat eu porta posuere aenean donec aenean massa arcu. Massa porta elit id leo! Sed suscipit donec turpis sapien penatibus!&nbsp;<a href="http://lorem.bobolo.se/#">Sed suscipit donec turpis sapien penatibus!&nbsp;</a>Vestibulum eget quis accumsan interdum erat. Eu etiam ullamcorper lectus hendrerit dui proin ridiculus tincidunt elit porta augue: Dui lacinia volutpat urna cras varius donec augue et, Libero amet felis et feugiat nisl sem, Dui hendrerit ut duis elementum sem a mattis dui. Velit vehicula egestas tortor et nulla, Hendrerit nunc at congue fermentum libero pretium dui etiam. Ullamcorper sed justo dapibus urna dui. In sit suscipit duis nulla urna gravida adipiscing pretium volutpat rhoncus.&nbsp;In sit suscipit duis nulla urna gravida adipiscing pretium volutpat rhoncus.</p>\n', '2013-01-30 08:32:15', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(14, 126, 1, NULL, 1, NULL, 'Venenatis, interdum, dapibus a sagittis', 'venenatis interdum dapibus a sagittis', NULL, '<h2>Venenatis, interdum, dapibus a sagittis</h2>\n\n<p>Volutpat imperdiet aenean at pretium! Dictum lorem augue eros dui convallis semper laoreet est id. Euismod dis ipsum nulla convallis arcu tristique. Adipiscing vivamus tellus euismod imperdiet lacus sit leo sed metus nisl. Nunc a egestas nibh donec nec at vel enim dolor. Enim rutrum adipiscing velit urna aliquam sollicitudin donec metus viverra at. A curabitur rutrum eu vivamus!&nbsp;<a href="http://lorem.bobolo.se/#">A curabitur rutrum eu vivamus!&nbsp;</a>Tempor odio hendrerit at porttitor amet cras cras rutrum hendrerit faucibus bibendum. Suspendisse quis donec ridiculus sit: Semper donec nec et neque et sollicitudin pellentesque nisl quis posuere. Purus a dapibus euismod nisi natoque penatibus tristique nec tristique purus:&nbsp;Purus a dapibus euismod nisi natoque penatibus tristique nec tristique purus:&nbsp;Dignissim feugiat neque ante dapibus mauris lorem interdum gravida mi nec,</p>\n\n<blockquote>\n<p>Odio eget suspendisse leo nulla bibendum augue erat libero viverra. Aliquam rutrum vitae consectetur adipiscing aliquam phasellus risus nisi cursus. Tortor dui neque at condimentum iaculis auctor non: Suspendisse amet erat in ipsum et sit accumsan. Nunc lectus urna phasellus nulla eu. Lacus parturient urna vivamus risus posuere amet magnis ut neque urna. Sagittis facilisis at sodales viverra a aliquam nunc orci. Nam neque dignissim blandit dapibus?</p>\n</blockquote>\n\n<p>Ligula pulvinar donec lectus velit tincidunt:&nbsp;Ligula pulvinar donec lectus velit tincidunt:&nbsp;<a href="http://lorem.bobolo.se/#">Ligula pulvinar donec lectus velit tincidunt:&nbsp;Ligula pulvinar donec lectus velit tincidunt:&nbsp;</a>Tortor ut ipsum nascetur in luctus vitae quis tincidunt eget eget? Lobortis eros lobortis sapien accumsan morbi nunc varius porttitor venenatis pharetra at. Dapibus cras imperdiet rhoncus tincidunt aenean molestie non: Commodo sed nec a pellentesque. Eros erat venenatis rutrum ut non nulla sit sapien accumsan. Vitae at non volutpat nec donec nec urna nisl leo fermentum; Sit sapien gravida nisi maecenas tincidunt vel placerat semper nec?&nbsp;Sit sapien gravida nisi maecenas tincidunt vel placerat semper nec?&nbsp;<a href="http://lorem.bobolo.se/#">Sit sapien gravida nisi maecenas tincidunt vel placerat semper nec?&nbsp;Sit sapien gravida nisi maecenas tincidunt vel placerat semper nec?&nbsp;</a>Mollis donec nec varius a aenean nec, Facilisis placerat dui enim dolor tincidunt neque malesuada volutpat neque ligula sociis. Dignissim malesuada vestibulum lorem blandit vel mollis neque vitae sed fermentum lacinia: Sagittis tincidunt eleifend gravida suspendisse est commodo non condimentum pretium dui: Sagittis massa nunc neque porta et facilisis. Eu lectus nunc mauris facilisis. Convallis dui tempor id ante eu pretium! Amet vitae eget felis elementum lorem tortor aliquet eget risus; Et risus nunc dui tellus.</p>\n\n<p>Eget rhoncus non nulla est urna sed. Luctus pretium ultricies magna penatibus dui urna accumsan facilisis arcu purus. Mauris venenatis amet risus risus dui interdum neque mi.Mauris venenatis amet risus risus dui interdum neque mi.&nbsp;Massa vehicula non ut vel amet, Sed varius sodales vitae interdum sed justo sed donec convallis, Ligula venenatis egestas pretium felis placerat ligula volutpat erat? Nascetur molestie pellentesque vestibulum lacus mus amet sodales. Dignissim pulvinar congue consequat bibendum fermentum dis facilisis cum a nec. Nec viverra in elit integer vivamus est adipiscing. Nullam curabitur dolor sed blandit ligula at interdum fermentum, Quisque vivamus augue vehicula nec diam sit vitae nulla donec imperdiet a. Ut pulvinar enim egestas urna semper elementum augue pretium: Mattis velit placerat vitae lacus gravida justo consectetur augue purus lacinia. Donec purus dui et pellentesque. Sapien parturient dictum quis accumsan venenatis gravida nulla, Ut semper vivamus nisi vitae non interdum vitae vel. Mauris fermentum aliquet eu tincidunt aenean sed vestibulum etiam sit. Dignissim sit blandit arcu leo magna egestas massa in libero ultrices facilisis.</p>\n\n<ul>\n	<li>Vestibulum eget fermentum erat risus eget! Nunc eros ligula mauris dictum tincidunt dui lorem augue rutrum convallis, Ipsum fusce eros ut erat elit phasellus pharetra mattis eget,&nbsp;Ipsum fusce eros ut erat elit phasellus pharetra mattis eget,&nbsp;Risus rhoncus sodales condimentum nulla justo enim odio rhoncus!</li>\n	<li>Parturient blandit sit sit in vitae blandit erat libero. Diam convallis venenatis augue cursus dolor. Vehicula felis mollis tincidunt nisl. Phasellus curabitur tellus posuere volutpat vitae malesuada facilisis. Quis auctor nulla semper porttitor nulla augue fermentum at risus; Iaculis consequat eget vivamus varius elementum! Nisl sollicitudin risus natoque purus dictum congue nec nam;</li>\n	<li>Risus blandit nunc blandit tempor nisl lectus aenean vitae: Dignissim posuere consectetur varius pulvinar justo egestas magnis:&nbsp;Dignissim posuere consectetur varius pulvinar justo egestas magnis:&nbsp;Romanus eunt domus. Eu velit tortor nulla sodales semper. Risus consequat semper egestas aenean egestas consectetur lacus. Porta elementum magnis nec sollicitudin sem vitae convallis suspendisse non lorem. Fermentum curabitur gravida sollicitudin elementum vel a metus neque,</li>\n	<li>Proin nec neque at blandit a consectetur eget bibendum facilisis enim tellus! Nunc pretium ut eu vestibulum nulla vivamus aenean. Posuere accumsan facilisis varius magna nam turpis rutrum turpis nec.&nbsp;Posuere accumsan facilisis varius magna nam turpis rutrum turpis nec.&nbsp;Turpis et vel sed sed vel cras vitae pharetra gravida sit gravida.&nbsp;Turpis et vel sed sed vel cras vitae pharetra gravida sit gravida.&nbsp;Velit at rutrum blandit tempor nec leo; Urna ridiculus aliquam pellentesque non tristique.</li>\n</ul>\n\n<p>Lobortis orci neque blandit lacinia lacinia a pellentesque. Mauris lectus sagittis risus nec non hendrerit eu convallis sed parturient! Gravida nunc mi id vel placerat consectetur suscipit viverra lacus non risus! Tellus phasellus congue augue cursus gravida non risus augue nec,&nbsp;Tellus phasellus congue augue cursus gravida non risus augue nec,&nbsp;Justo nunc eget nisl vel pretium consectetur mollis ultricies venenatis lacus,&nbsp;Justo nunc eget nisl vel pretium consectetur mollis ultricies venenatis lacus,&nbsp;Nec eget morbi mi dui porta urna tincidunt. Laoreet aliquam hendrerit amet lorem leo tincidunt. Penatibus elit nam feugiat porta ante lorem feugiat ut ante urna! Cras nisl donec imperdiet nec interdum blandit a mauris ridiculus; Phasellus lorem risus facilisis vel. Nam velit velit molestie neque sed purus iaculis in leo! Urna sociis feugiat fringilla laoreet libero. Magnis lorem est erat pharetra adipiscing posuere aliquam malesuada ut enim. Tristique leo lectus dui vitae justo eget non pellentesque vel nulla vitae.&nbsp;<a href="http://lorem.bobolo.se/#">Tristique leo lectus dui vitae justo eget non pellentesque vel nulla vitae.&nbsp;</a>Ut enim bibendum nulla aenean sagittis:</p>\n\n<p>In quam turpis sociis amet ut amet bibendum et non: Ligula convallis sit dolor dolor risus malesuada orci phasellus mauris; Ipsum lacinia nisl ut varius. Vehicula nulla aenean enim neque amet vestibulum: Eget eros erat eget felis facilisis ligula pellentesque rutrum ultricies. Posuere dui vitae aenean congue sed donec gravida dis sed nulla, Dictum aenean pulvinar iaculis porta enim et velit. Ut risus phasellus hendrerit pellentesque donec ipsum pharetra volutpat at tincidunt sodales.&nbsp;Ut risus phasellus hendrerit pellentesque donec ipsum pharetra volutpat at tincidunt sodales.&nbsp;Nec eu mi in ut eu lectus?&nbsp;Nec eu mi in ut eu lectus?&nbsp;Nibh proin eu facilisis commodo purus porttitor libero porttitor lacus at duis. Viverra congue suscipit nam pretium egestas et bibendum? Nibh feugiat nam ut dolor lorem accumsan dolor sed bibendum adipiscing ut; Dolor sagittis eros nec risus. Tortor vel pretium nulla ac risus vel tristique laoreet sociis.</p>\n', '2013-01-30 08:33:25', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(15, 127, 1, NULL, 1, NULL, 'Fixa en sak...', 'fixa en sak', NULL, '<h2>Ut lorem, pretium tellus erat porta adipiscing lacus</h2>\n\n<p>Vitae augue eget porta neque volutpat metus in pellentesque at. Lobortis faucibus pharetra montes dolor justo dolor facilisis hendrerit rhoncus mauris; Vitae enim nunc ante semper neque. Sodales consectetur cursus pharetra phasellus vestibulum cursus nisl lorem maecenas? Vivamus justo commodo eleifend donec iaculis sodales mi vitae.Vivamus justo commodo eleifend donec iaculis sodales mi vitae.&nbsp;<a href="http://lorem.bobolo.se/#">Vivamus justo commodo eleifend donec iaculis sodales mi vitae.&nbsp;Vivamus justo commodo eleifend donec iaculis sodales mi vitae.&nbsp;</a>Nec convallis vitae tellus metus sed quis eu cras eu. Pretium vitae mi elementum vestibulum lectus mauris lacus sapien aenean. Interdum aliquam est placerat augue. Elementum mus nulla vel ligula enim!&nbsp;<a href="http://lorem.bobolo.se/#">Elementum mus nulla vel ligula enim!&nbsp;</a>Facilisis dignissim luctus tristique a phasellus velit donec mauris velit vivamus non. Rhoncus mattis sed lorem tristique erat id. Pretium tincidunt felis non sed: Sollicitudin rutrum fusce tempor ut lectus neque enim curabitur aliquam.&nbsp;Sollicitudin rutrum fusce tempor ut lectus neque enim curabitur aliquam.&nbsp;Nibh dapibus vivamus sed at risus urna lacus! Bibendum iaculis dapibus volutpat rutrum vitae aenean cras sed. Integer risus eget eget sapien eget risus volutpat vitae duis: In ipsum eu dolor consequat porta erat massa nunc mollis eu:&nbsp;In ipsum eu dolor consequat porta erat massa nunc mollis eu:</p>\n\n<ul>\n	<li>Dui aliquam mauris risus curabitur bibendum semper libero at. Mauris libero dis risus ipsum nec arcu aliquam tincidunt natoque. Vivamus a pretium et quis ut nulla fusce eget. Sociis eget risus sem arcu nunc pretium eleifend! Tristique ligula gravida erat odio dictum sodales.</li>\n	<li>Donec risus sodales velit dui porta nunc vitae. Sociis malesuada tincidunt quisque nisl rhoncus dui malesuada eros sodales. Ridiculus ultrices accumsan nulla blandit donec vestibulum nisl sed consequat hendrerit sed? Proin metus vel porta mauris aenean sit luctus fermentum eget tincidunt blandit. Venenatis nulla molestie mauris ipsum nec; Integer cras ligula amet tincidunt sodales leo a donec fermentum phasellus.</li>\n	<li>Odio ut ac nam pharetra porta. Vitae non quam justo porta nulla feugiat at. Volutpat porta volutpat volutpat pulvinar vivamus tellus euismod sed convallis nec; Adipiscing id ac dis lorem quis cursus nisi quis a nunc dignissim, Leo phasellus elit nulla aliquam semper at dui consectetur amet diam.</li>\n</ul>\n\n<p>Sodales leo pellentesque egestas aenean risus.&nbsp;Sodales leo pellentesque egestas aenean risus.&nbsp;Eget eros lacus facilisis adipiscing? Aliquam mauris lacinia quis venenatis neque placerat arcu; Ipsum sodales curabitur nam ut enim, Purus mauris nunc donec vitae et vitae: Volutpat arcu lorem non ligula nec enim? Est nulla ridiculus luctus non mauris porta justo porttitor risus! Arcu ipsum sed lacus ipsum dolor vitae a? Odio varius magna facilisis laoreet: Erat a placerat ultricies erat non? Vestibulum pellentesque in hendrerit id a nulla pellentesque sapien hendrerit libero; Facilisis quis in amet fermentum ac vestibulum. Ligula odio sapien gravida sed duis lacus; Curabitur metus amet lectus amet erat ut eget urna suspendisse.&nbsp;<a href="http://lorem.bobolo.se/#">Curabitur metus amet lectus amet erat ut eget urna suspendisse.&nbsp;</a>Vestibulum mattis risus sapien consequat donec pellentesque sit amet nulla diam? Cum non integer vel justo eleifend tincidunt! Id sit dui lacinia lectus enim porta fermentum eget gravida? Sit parturient placerat eros libero egestas dolor erat amet vestibulum luctus donec,&nbsp;Sit parturient placerat eros libero egestas dolor erat amet vestibulum luctus donec,&nbsp;Dui arcu integer ridiculus aliquam pellentesque massa interdum ultrices non. Pellentesque iaculis ut nec quam sagittis elit proin sodales consequat in turpis!&nbsp;Pellentesque iaculis ut nec quam sagittis elit proin sodales consequat in turpis!</p>\n\n<blockquote>\n<p>Fusce turpis tortor lorem dis ut sed et consectetur. Nisl consectetur sit eu risus: Sapien porta tristique eu bibendum lectus nec est risus nam risus egestas. Sapien porta tristique eu bibendum lectus nec est risus nam risus egestas. Elementum vitae a aliquam sem vitae dolor porta justo vestibulum risus id.</p>\n</blockquote>\n\n<p>Tincidunt urna malesuada cum hendrerit ligula dui pretium at risus duis! Non gravida vel non amet. Pretium sed egestas tempor mattis ligula odio vivamus dui urna. Placerat luctus turpis eros cursus dolor fermentum? Duis blandit fermentum consectetur sapien pretium dolor: Mauris porta vestibulum consectetur lacus; Augue vitae tincidunt in facilisis pretium consectetur urna porttitor!&nbsp;Augue vitae tincidunt in facilisis pretium consectetur urna porttitor!&nbsp;Erat erat nec sem vivamus risus est interdum? Quis ultrices turpis volutpat velit risus sapien ligula augue pulvinar lacinia nec. Sollicitudin volutpat dolor suspendisse eget. Justo risus sem nam pharetra viverra risus enim id. Eu felis odio ut elementum blandit dignissim mus quam est eget risus. Turpis volutpat a aliquet sed cras erat aenean eget pretium quisque, Lacinia sed consectetur id vestibulum nec accumsan phasellus donec: Ut adipiscing morbi sit dui nullam ut sed non nec. Iaculis porta gravida urna leo dui dis neque non nec eleifend eget. Nullam pulvinar facilisis bibendum elit nibh mauris: Vestibulum tincidunt malesuada gravida nec lacus fringilla gravida nec blandit congue!&nbsp;Vestibulum tincidunt malesuada gravida nec lacus fringilla gravida nec blandit congue!Purus lorem dolor massa dis rutrum. Dui vestibulum est in justo fusce tincidunt nec et ligula mauris.</p>\n\n<p>Cursus vel feugiat tincidunt placerat. Sit neque lorem elit ipsum odio ligula gravida leo tellus;&nbsp;<a href="http://lorem.bobolo.se/#">Sit neque lorem elit ipsum odio ligula gravida leo tellus;&nbsp;</a>Aliquam volutpat augue nisl lacus metus, Eu amet sodales dis placerat quis lacus tincidunt?&nbsp;<a href="http://lorem.bobolo.se/#">Eu amet sodales dis placerat quis lacus tincidunt?&nbsp;</a>Eget non risus a bibendum risus fermentum vivamus aliquam aenean. Cursus neque venenatis ipsum nec nisi cras sed volutpat metus. At nisl consequat dolor eu eget justo non pretium! Quis neque facilisis in eget? Lobortis est nisl ullamcorper nunc cursus convallis quisque eleifend porta:&nbsp;Lobortis est nisl ullamcorper nunc cursus convallis quisque eleifend porta:&nbsp;Massa cum eget etiam elementum eget. Eros non lacus facilisis enim magnis sollicitudin sed iaculis volutpat in integer. Sodales dolor consectetur iaculis facilisis amet facilisis bibendum consectetur quam? Suscipit nunc parturient quam nunc; Nunc phasellus nulla pulvinar ipsum; Tristique faucibus fermentum bibendum rhoncus luctus pharetra interdum eu consectetur!</p>\n\n<p>Nisl dolor lectus arcu at donec bibendum nec sit rutrum: Eget velit ut viverra bibendum ac risus tincidunt venenatis. Nec cras ut urna cursus nunc proin mollis sodales sodales urna nisl. Convallis lectus orci sapien leo. Non blandit nunc aenean mauris hendrerit posuere enim. Donec sit tristique venenatis suscipit curabitur risus nibh leo nec metus maecenas. Auctor porttitor nisl nulla mi bibendum arcu! Aliquet turpis pellentesque varius quis varius at gravida. Neque quam euismod tristique nisi odio est lectus nascetur:Neque quam euismod tristique nisi odio est lectus nascetur:&nbsp;Gravida phasellus amet hendrerit justo tortor nisi facilisis dolor pellentesque nibh; Erat cras nisi venenatis semper consectetur aliquam imperdiet arcu ut turpis tempor. Phasellus nibh eu sed donec lacus fermentum lorem sagittis phasellus fermentum sapien. Nisl eget leo porta urna suscipit cum dapibus ipsum; Facilisis vitae vestibulum pretium risus mollis urna eu a? Ridiculus facilisis a egestas mauris convallis lacinia mauris; Dignissim nulla congue nec viverra. Montes sed mollis erat dolor nam dictum risus nulla aliquam nam. Eu gravida pharetra nec dui. Convallis aliquet iaculis massa ultrices quam luctus augue neque pellentesque cum eu.</p>\n', '2013-01-30 08:35:07', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(16, 128, 1, NULL, 1, NULL, 'Salta lösenord när du skapa användare', 'salta losenord nar du skapa anvandare', NULL, '<ul>\n	<li>G&ouml;r detta genom att mellanlagra l&ouml;senordet och konfirmeringen och skicka tillbaka dess om det blir fel?</li>\n</ul>\n', '2013-01-30 08:36:18', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(17, 129, 1, NULL, 1, NULL, 'Fixa versionshantering', 'fixa versionshantering', NULL, '<p>Kom p&aring; n&aring;got smart med hur man sparar versioner.</p>\n\n<ol>\n	<li>Skapa f&ouml;rsta draft</li>\n	<li>Publicera\n	<ol>\n		<li>Redigera publicerad</li>\n		<li>Skapa nytt draft</li>\n	</ol>\n	</li>\n	<li>Repetera</li>\n</ol>\n', '2013-01-30 08:37:29', 1, '2013-01-30 08:37:41', 0);
INSERT INTO `cyan_post_data` VALUES(18, 130, 1, NULL, 1, NULL, 'En sida till', 'en sida till', NULL, '<p>Titta p&aring; TV nu!</p>\n', '2013-01-31 21:31:40', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(19, 131, 1, NULL, 1, NULL, 'Och så var det fredag!', 'och sa var det fredag', NULL, '<p>Sweet!</p>\n', '2013-02-01 06:19:51', 1, '2013-02-01 06:19:57', 0);
INSERT INTO `cyan_post_data` VALUES(20, 132, 1, NULL, 1, NULL, 'Och så var det fredag', 'och sa var det fredag', NULL, '', '2013-02-01 18:56:31', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(21, 133, 1, NULL, 1, NULL, 'Snart fixa med tvätten', 'snart fixa med tvatten', NULL, '', '2013-02-01 18:56:45', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(22, 134, 1, NULL, 1, NULL, 'Gonk!', 'gonk', NULL, '', '2013-02-01 18:56:53', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(23, 135, 1, NULL, 1, NULL, 'Album 2', 'album 2', NULL, '<p>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;background: #fff url(&quot;../img/be-sprite.png&quot;) repeat-x 0 -760px;</p>\n\n<p>&nbsp;</p>\n', '2013-02-01 18:57:03', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(24, 136, 1, NULL, 1, NULL, 'En ny på music', 'en ny pa music', NULL, '<p>En ny p&aring; music</p>\n', '2013-02-02 16:13:26', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(25, 137, 1, NULL, 1, NULL, 'En artikel i portföljkategorin', 'en artikel i portfoljkategorin', NULL, 'Hej och hå', '2013-02-02 20:11:45', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(26, 138, 1, NULL, 1, NULL, 'Columbia', 'columbia', NULL, '<p>Porta cursus consequat donec aliquam at eros sapien. Vitae tempor cursus lorem mi integer luctus pretium. Amet odio augue nec dolor rutrum malesuada dui. Orci ut turpis turpis sit eget turpis felis mattis. Erat imperdiet felis tristique sapien cursus iaculis vel laoreet lacus. Elit adipiscing vel sociis accumsan semper dignissim at. Mauris faucibus mauris massa pharetra nunc volutpat sit libero iaculis purus. Eu quis malesuada malesuada sem accumsan est blandit, Interdum ligula mauris rutrum elementum proin dui sit pharetra parturient? Lacus curabitur hendrerit rhoncus at ultrices sed feugiat urna pretium. Donec nulla integer neque eget sapien semper etiam! Nisl metus est risus dis pharetra blandit libero. Pretium amet hendrerit phasellus ut. Varius sed hendrerit non elit facilisis tempor vestibulum nam consequat porta fusce.</p>\n\n<h2>Yeah, detta &auml;r en rubrik</h2>\n\n<p>Volutpat eu volutpat cursus dui nibh accumsan nunc id nascetur! Donec dignissim placerat at ipsum sagittis pharetra non erat amet, Sem congue donec quis mollis ullamcorper ut nec leo velit nulla. Integer et luctus consequat lectus elit nam eget enim at eu, Tellus aliquam mauris leo molestie urna gravida pellentesque est lacus, Mi mollis turpis mauris sodales. Romani ite domum. Dolor venenatis non arcu eget vestibulum consectetur luctus non adipiscing? Eu aliquam urna dui tellus varius cras;</p>\n\n<p>At orci dictum lorem varius vivamus; Non tincidunt porta dolor hendrerit sit euismod vestibulum vitae suspendisse sit, Aenean sagittis nec vitae dictum adipiscing auctor odio fermentum pretium. Sem velit sed sed arcu ligula fermentum pretium lacinia eu consectetur. Nec eget lacus leo urna lacus adipiscing urna lacus sed! At adipiscing hendrerit nec pharetra augue arcu sollicitudin, Eget donec elit nec ligula malesuada sit consectetur fermentum pellentesque amet?</p>\n\n<p>Rhoncus congue elementum facilisis nisl consectetur vel quis ultrices cursus aliquam. Phasellus amet mauris lacus eu massa felis curabitur non lacinia vivamus: Tristique vel tempor erat lacus mi tristique phasellus fermentum non tincidunt; Suscipit lectus turpis aenean tincidunt dolor dolor: Nunc accumsan vel euismod adipiscing enim a nulla volutpat elementum aenean. Placerat congue urna urna donec amet dapibus sapien imperdiet etiam; Gravida hendrerit sociis aenean quis libero vitae dui a. Eu nunc nunc nam aliquam volutpat urna nunc montes velit aliquam. Facilisis rhoncus non varius lectus eget neque felis malesuada aliquet,</p>\n\n<p>Varius sit dui nulla blandit metus aliquet rutrum dui lorem: Non nec parturient blandit vehicula turpis purus eros; Dapibus condimentum mauris lorem montes pharetra lectus feugiat a. Turpis amet mauris vel nunc sit: In id adipiscing diam et nec felis viverra tincidunt ullamcorper lectus; Non sit enim hendrerit cursus augue a arcu elit. Eget massa vel facilisis vestibulum eu nec lectus nulla. Nisl sem phasellus sagittis risus erat quam mollis purus nibh aliquam. Placerat sodales nec pretium sed dignissim nulla tristique luctus tempor lectus. Convallis dolor varius est gravida lacus! Orci ultricies urna sit faucibus elit placerat dolor: Eu laoreet cras urna tortor a sapien nulla. Enim enim rhoncus sit erat suspendisse non sed tempor nulla non ut: Porta ligula nisi ipsum dignissim euismod enim vestibulum pretium consequat</p>\n', '2013-02-03 20:29:02', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(27, 139, 1, NULL, 1, NULL, 'Detta är en ny page', 'detta ar en ny page', NULL, '<p>G&aring; till jobbet NU.</p>\n', '2013-02-04 08:07:46', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(28, 140, 1, NULL, 1, NULL, 'Jobba jobba!', 'jobba jobba', NULL, '<p>asdf</p>\n', '2013-02-04 08:08:11', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(29, 141, 1, NULL, 1, NULL, 'weee', 'weee', NULL, '<p>&lt;?php echo __(&quot;Fields&quot;); ?&gt;</p>\n', '2013-02-04 08:08:22', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(30, 142, 1, NULL, 1, NULL, 'Yeah!', 'yeah', NULL, 'messages_pager', '2013-02-04 22:13:29', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(31, 143, 1, NULL, 1, NULL, 'Pokalen!', 'pokalen', NULL, 'messages_pager', '2013-02-04 22:13:46', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(32, 144, 1, NULL, 1, NULL, 'Boy & Bear', 'boy bear', NULL, '', '2013-02-04 22:14:04', 1, '2013-02-04 22:14:12', 0);
INSERT INTO `cyan_post_data` VALUES(33, 145, 1, NULL, 1, NULL, 'En på kontoret till... ', 'en pa kontoret till', NULL, 'Gå och chilla nu...', '2013-02-04 22:14:44', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(34, 146, 1, NULL, 1, NULL, 'Raketen!', 'raketen', NULL, '', '2013-02-04 22:15:15', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(35, 147, 1, NULL, 1, NULL, 'Första på en ny typ', 'forsta pa en ny typ', NULL, '', '2013-02-05 08:25:23', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(36, 148, 1, NULL, 1, NULL, 'En till på ny typ (2)', 'en till pa ny typ 2', NULL, '', '2013-02-05 08:29:15', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(37, 149, 1, NULL, 1, NULL, 'Mikrofontjossan!', 'mikrofontjossan', NULL, '', '2013-02-05 08:35:01', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(38, 150, 1, NULL, 1, NULL, 'Tredje på ny typ', 'tredje pa ny typ', NULL, 'wee!', '2013-02-05 08:35:21', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(39, 151, 1, NULL, 1, NULL, 'Liten glitch i menyn', 'liten glitch i menyn', NULL, 'På Contentfliken buggar det lite i vänsterkanten när den är "active"', '2013-02-05 08:37:06', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(40, 152, 1, NULL, 1, NULL, 'dfghjk', 'dfghjk', NULL, '<p>dfghjk</p>\n', '2013-02-06 16:59:07', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(41, 153, 1, NULL, 1, NULL, 'fg', 'fg', NULL, 'fgh', '2013-02-06 16:59:56', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(42, 154, 1, NULL, 1, NULL, 'En ny sida! x2', 'en ny sida x2', NULL, 'Weeeho!', '2013-02-16 11:17:39', 1, '2013-02-16 11:18:18', 0);
INSERT INTO `cyan_post_data` VALUES(43, 155, 1, NULL, 1, NULL, 'Ett nytt content på kontorstypen', 'ett nytt content pa kontorstypen', NULL, 'Yay!', '2013-02-16 13:38:27', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(44, 156, 1, NULL, 1, NULL, 'Ett drinkrecept', 'ett drinkrecept', NULL, 'joomomomom', '2013-02-21 08:50:41', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(45, 157, 1, NULL, 1, NULL, 'A test content!', 'a test content', NULL, '', '2013-02-25 21:21:13', 1, NULL, 0);
INSERT INTO `cyan_post_data` VALUES(46, 158, 1, NULL, 1, NULL, 'Helan går', 'helan gar', NULL, '', '2013-02-27 21:06:31', 1, '2013-02-27 21:06:38', 0);
INSERT INTO `cyan_post_data` VALUES(47, 159, 1, NULL, 1, NULL, 'Ett annat album', 'ett annat album', NULL, '', '2013-03-12 22:45:51', 1, NULL, 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_post_meta`
--

CREATE TABLE `cyan_post_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_meta_key` (`key`),
  KEY `fk_post_id` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_post_meta`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_post_relations`
--

CREATE TABLE `cyan_post_relations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `related_id` int(10) unsigned NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_post_id` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_post_relations`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_queue`
--

CREATE TABLE `cyan_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `recipient_email` varchar(150) NOT NULL,
  `recipient_name` varchar(10) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `text_html` text NOT NULL,
  `text_plain` text NOT NULL,
  `scheduled_date` datetime DEFAULT NULL,
  `processed_date` datetime DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_queue`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_roles`
--

CREATE TABLE `cyan_roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '1',
  `site_id` tinyint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Data i tabell `cyan_roles`
--

INSERT INTO `cyan_roles` VALUES(1, 0, 'login', NULL, 'Login privileges, granted after account confirmation', 1, 0);
INSERT INTO `cyan_roles` VALUES(2, 0, 'admin', NULL, 'Administrative user, has access to everything.', 1, 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_roles_users`
--

CREATE TABLE `cyan_roles_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data i tabell `cyan_roles_users`
--

INSERT INTO `cyan_roles_users` VALUES(1, 1);
INSERT INTO `cyan_roles_users` VALUES(6, 1);
INSERT INTO `cyan_roles_users` VALUES(7, 1);
INSERT INTO `cyan_roles_users` VALUES(8, 1);
INSERT INTO `cyan_roles_users` VALUES(13, 1);
INSERT INTO `cyan_roles_users` VALUES(14, 1);
INSERT INTO `cyan_roles_users` VALUES(15, 1);
INSERT INTO `cyan_roles_users` VALUES(16, 1);
INSERT INTO `cyan_roles_users` VALUES(17, 1);
INSERT INTO `cyan_roles_users` VALUES(18, 1);
INSERT INTO `cyan_roles_users` VALUES(19, 1);
INSERT INTO `cyan_roles_users` VALUES(20, 1);
INSERT INTO `cyan_roles_users` VALUES(21, 1);
INSERT INTO `cyan_roles_users` VALUES(22, 1);
INSERT INTO `cyan_roles_users` VALUES(23, 1);
INSERT INTO `cyan_roles_users` VALUES(24, 1);
INSERT INTO `cyan_roles_users` VALUES(25, 1);

-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_sites`
--

CREATE TABLE `cyan_sites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `variables` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_sites`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_term_taxonomy`
--

CREATE TABLE `cyan_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_term_taxonomy`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_types`
--

CREATE TABLE `cyan_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `description` text,
  `configuration` text NOT NULL,
  `display` text,
  `sort` int(10) unsigned NOT NULL DEFAULT '1',
  `site_id` tinyint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Data i tabell `cyan_types`
--

INSERT INTO `cyan_types` VALUES(1, 'Page', 'page', 'page', 'Beskrivning...', 'Vilka fält som ligger var i ADMIN.', 'Koden för att visa här...', 1, 0);
INSERT INTO `cyan_types` VALUES(3, 'Musik', 'musik', 'notes', '', '', '', 3, 0);
INSERT INTO `cyan_types` VALUES(6, 'Raketer', 'raketer', 'rocket', '', '', '', 1, 0);
INSERT INTO `cyan_types` VALUES(7, 'Buggar', 'faffa2', 'prize', '', '', '', 2, 0);
INSERT INTO `cyan_types` VALUES(13, 'Kontorstypen', 'fraggel', 'briefcase', 'desc', 'conf', 'display CODE', 1, 0);
INSERT INTO `cyan_types` VALUES(16, 'En andra sida', 'sida2', 'paperclip', 'desc', 'conf', 'disp', 1, 0);
INSERT INTO `cyan_types` VALUES(17, 'test', 'test', 'microphone', 'description', 'conf', 'display', 1, 0);
INSERT INTO `cyan_types` VALUES(18, 'Features', 'features', 'flag', '', '', '', 8, 0);
INSERT INTO `cyan_types` VALUES(19, 'Händelser', 'events', 'calendar', '', '', '', 1, 0);
INSERT INTO `cyan_types` VALUES(20, 'Zombietyp.', 'zombietyp', 'book', '', '', '', 9, 0);
INSERT INTO `cyan_types` VALUES(21, 'En ny typ', 'type', 'compass', '', '', '', 1, 0);
INSERT INTO `cyan_types` VALUES(22, 'Album', 'album', 'notes', '', '', '', 0, 0);
INSERT INTO `cyan_types` VALUES(23, 'Frukostställe', 'frukostställe', 'comment', '', '', '', 0, 0);
INSERT INTO `cyan_types` VALUES(24, 'Artist', 'artist', 'user', '', '', '', 0, 0);
INSERT INTO `cyan_types` VALUES(25, 'Snapsvisa', 'snapsvisa', 'microphone', '', '', '', 0, 0);
INSERT INTO `cyan_types` VALUES(26, 'Melodier', 'melodier', 'notes', '', '', '', 0, 0);
INSERT INTO `cyan_types` VALUES(27, 'Låt', 'lat', 'note', '', '', '', 0, 0);
INSERT INTO `cyan_types` VALUES(28, 'Drinkrecept', 'drinkrecept', 'comment', '', '', '', 0, 0);
INSERT INTO `cyan_types` VALUES(29, 'SEO-tips', 'seo-tips', 'bell', '', '', '', 9, 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_users`
--

CREATE TABLE `cyan_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(127) NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `username_nice` varchar(64) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `password` varchar(64) NOT NULL,
  `salt` varchar(64) NOT NULL,
  `logins` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `activation_key` varchar(64) DEFAULT NULL,
  `color` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `star` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`),
  UNIQUE KEY `uniq_username_nice` (`username_nice`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Data i tabell `cyan_users`
--

INSERT INTO `cyan_users` VALUES(1, 'anders@bobolo.se', 'admin', 'admin', NULL, NULL, '0faf66c33ae7d33fb1ec29a5b8352686e3787d076bcb3a8ae8a12df4dc509663', 'salt', 186, '2013-03-12 21:25:59', NULL, 0, 0, 1);
INSERT INTO `cyan_users` VALUES(6, 'anders.dahlgren@gmail.com', 'member', 'member', NULL, NULL, '0ad3cd63731dc6804df9e040fa45f6fde7e2e88939370c73ee7d818112af51d3', '', 0, NULL, NULL, 0, 0, 1);
INSERT INTO `cyan_users` VALUES(7, 'anders.dahlgren+1@gmail.com', 'anders', 'anders', NULL, NULL, '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 2, '2013-01-06 15:21:44', NULL, 0, 0, 1);
INSERT INTO `cyan_users` VALUES(8, 'anders.dahlgren+2@gmail.com', 'Kalle2', 'kalle2', NULL, NULL, '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 0, NULL, NULL, 0, 0, 1);
INSERT INTO `cyan_users` VALUES(13, 'anders.dahlgren+3@gmail.com', 'Kalle23', 'kalle23', NULL, NULL, '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 0, NULL, NULL, 0, 0, 1);
INSERT INTO `cyan_users` VALUES(14, 'anders.dahlgren+4@gmail.com', 'kalle3', 'kalle3', NULL, NULL, '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 0, NULL, NULL, 0, 0, 1);
INSERT INTO `cyan_users` VALUES(15, 'anders+2@bobolo.se', 'Orvar', 'orvar', NULL, NULL, '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', 'NzMB1uPRQHZOfsOmSxBGtSWazpshC8iwZHXVLEC08ZNm7qJZJ64Wc1UcOVSBWe97', 0, NULL, NULL, 0, 0, 1);
INSERT INTO `cyan_users` VALUES(16, 'stina@bobolo.se', 'Stina2', 'stina2', NULL, NULL, '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 5, '2013-01-06 18:18:18', NULL, 0, 0, 1);
INSERT INTO `cyan_users` VALUES(17, 'flisa@bobolo.se', 'Flisa', 'flisa', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'm83ESO2nRdJ1eHpqEKvvTrkYVQbTcNdzX3JySiijvoIiPAPagMJ1FIKwf4g0cwo3', 1, '2013-01-06 18:40:04', NULL, 0, 0, 0);
INSERT INTO `cyan_users` VALUES(18, 'azze@bobolo.se', 'Azzé', 'azze', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'jA8EkRRNbzftKfDBqiUqw70y0oVBSM3hQGHcyvLb1yfUgGRweikUlcuOhCwmC1TT', 1, '2013-01-06 19:44:27', NULL, 0, 0, 1);
INSERT INTO `cyan_users` VALUES(19, 'anders+3@bobolo.se', 'جستجو · تصاویر', '', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'L8oO33QmYD3J6GBRaPJE1ff6aIQ5Tl3qt3zxKiM8IDh0Qb4aq9NtHySwWqPk0wAh', 1, '2013-01-06 19:47:24', NULL, 0, 0, 0);
INSERT INTO `cyan_users` VALUES(20, 'anders.dahlgren+5@gmail.com', 'Olle', 'olle', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'umFtwkftocyJO1qrk5k0U7TtIohwaI8bKEnDhJEdfY0ge3itiwerz5fdLqCSm6OW', 2, '2013-01-09 07:45:37', NULL, 0, 0, 0);
INSERT INTO `cyan_users` VALUES(21, 'info@bobolo.se', 'Sven', 'sven', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'y1L99JyK7XCefCBMUsjCaaNni3XRKIJLhyALc3Tpf8KRym6FzH7wuLyj6sqbVsmm', 1, '2013-01-09 08:06:44', NULL, 0, 0, 0);
INSERT INTO `cyan_users` VALUES(22, 'anders.dahlgren+6@gmail.com', 'fekal', 'fekal', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'xTJs0pMT0kJCHQ85PQl0m1vRgSQPhO7F1bDe5lZy0WtPhRyuIQ7wSk8jFRSpaJZ1', 1, '2013-01-09 08:31:59', NULL, 0, 0, 0);
INSERT INTO `cyan_users` VALUES(23, 'anders.dahlgren+123@gmail.com', 'kevin', 'kevin', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'jLIAZoFXtvZweqg4EIOJfhS9U3T94yvwK2lf2li0lkJFxwtHRSAjh2cNeUXWVzna', 0, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_users` VALUES(24, 'webmaster@bobolo.se', 'ollekalle', 'ollekalle', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'GLK74WjgzWbPOWR8v15zYTlBJP9tgvMUhDIMZAuY7Y2ju0IpH5yYbh4ooVDkWl5L', 0, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_users` VALUES(25, 'anders.dahlgren+7@gmail.com', 'Faisol', 'faisol', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'VlvFcFSMqrqPdqAK2skhVqRPq8mAcOR4FXogtX9tRXmURcfDOHs3cFp12a3LLnFB', 0, NULL, NULL, 0, 0, 0);
INSERT INTO `cyan_users` VALUES(26, 'anders.dahlgren+8@gmail.com', 'Omar', 'omar', NULL, NULL, 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'fAY2hCGSwlRT5hIGHT4hlWBQngcwi2l7hkXK8JscHD16WTJrKWPIuYSx1RcS2X0o', 0, NULL, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_user_meta`
--

CREATE TABLE `cyan_user_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_meta_key` (`key`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_user_meta`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `cyan_user_tokens`
--

CREATE TABLE `cyan_user_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(40) NOT NULL,
  `type` varchar(100) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `cyan_user_tokens`
--


--
-- Restriktioner för dumpade tabeller
--

--
-- Restriktioner för tabell `cyan_post_data`
--
ALTER TABLE `cyan_post_data`
  ADD CONSTRAINT `post_data_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `cyan_posts` (`id`) ON DELETE CASCADE;

--
-- Restriktioner för tabell `cyan_post_meta`
--
ALTER TABLE `cyan_post_meta`
  ADD CONSTRAINT `post_meta_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `cyan_posts` (`id`) ON DELETE CASCADE;

--
-- Restriktioner för tabell `cyan_roles_users`
--
ALTER TABLE `cyan_roles_users`
  ADD CONSTRAINT `cyan_roles_users_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `cyan_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cyan_roles_users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `cyan_roles` (`id`) ON DELETE CASCADE;

--
-- Restriktioner för tabell `cyan_user_meta`
--
ALTER TABLE `cyan_user_meta`
  ADD CONSTRAINT `user_meta_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `cyan_user_meta` (`id`) ON DELETE CASCADE;

--
-- Restriktioner för tabell `cyan_user_tokens`
--
ALTER TABLE `cyan_user_tokens`
  ADD CONSTRAINT `cyan_user_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `cyan_users` (`id`) ON DELETE CASCADE;
