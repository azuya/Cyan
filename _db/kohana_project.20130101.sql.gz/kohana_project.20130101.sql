-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Värd: localhost
-- Skapad: 01 januari 2013 kl 20:11
-- Serverversion: 5.5.9
-- PHP-version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databas: `kohana_project`
--

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_comments`
--

CREATE TABLE `bliss_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) NOT NULL,
  `comment` text NOT NULL,
  `time` datetime NOT NULL,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_content` (`content_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Data i tabell `bliss_comments`
--

INSERT INTO `bliss_comments` VALUES(1, 5, 'Testar!', '0000-00-00 00:00:00', 'Anders', 'anders@bobolo.se');
INSERT INTO `bliss_comments` VALUES(2, 5, 'Testar!', '0000-00-00 00:00:00', 'Anders', 'anders@bobolo.se');
INSERT INTO `bliss_comments` VALUES(3, 5, 'WEeeho!', '0000-00-00 00:00:00', 'Kalle Balle', '');

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_content`
--

CREATE TABLE `bliss_content` (
  `content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_parent_content_id` int(10) unsigned DEFAULT NULL,
  `content_type_id` varchar(40) DEFAULT NULL,
  `content_visible` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `content_canonical_url` varchar(255) DEFAULT NULL,
  `content_order` int(10) unsigned NOT NULL DEFAULT '0',
  `content_password` varchar(40) DEFAULT NULL,
  `content_mime_type` varchar(50) DEFAULT NULL,
  `content_author` int(10) unsigned DEFAULT NULL,
  `content_start_date` datetime DEFAULT NULL,
  `content_end_date` datetime DEFAULT NULL,
  `content_comment_allowed` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `content_rating_allowed` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `content_like_allowed` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `content_comment_count` int(10) unsigned NOT NULL DEFAULT '0',
  `content_rating` float unsigned NOT NULL DEFAULT '0',
  `content_rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `content_like_count` int(10) unsigned NOT NULL DEFAULT '0',
  `subsite_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`),
  KEY `ix_content_type_id` (`content_type_id`),
  KEY `ix_content_parent_id` (`content_parent_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `bliss_content`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_contents`
--

CREATE TABLE `bliss_contents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `type_id` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text,
  `testar` varchar(100) DEFAULT NULL,
  `author_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Data i tabell `bliss_contents`
--

INSERT INTO `bliss_contents` VALUES(3, 0, 1, 'Boyah! '' och " och BREAK''*´^1ÜŒˆ`Y', '<p>Boyah! &#39; och &quot; och BREAK&#39;*&acute;^1&Uuml;&OElig;&circ;`Y</p>\n\n<p>In magnis ipsum sed vel: Sit sapien integer phasellus fermentum eget! Erat ipsum magnis eros dolor nibh erat dis nec nam. Leo suscipit orci at eleifend nam in in sapien sagittis elit. Romanus eunt domus. Suspendisse nunc erat dolor nibh convallis dui phasellus: Porta non neque porttitor nec fusce sollicitudin lorem convallis lectus justo. Accumsan porta dignissim proin non placerat. Dolor nibh arcu tincidunt ut pulvinar urna amet. Erat nunc nullam sed ut fusce egestas,</p>\n\n<p>Duis gravida vestibulum porta sollicitudin enim nam? Venenatis venenatis vivamus suspendisse elementum mollis? Tellus accumsan augue et cursus laoreet nulla: Dignissim lacus vitae nisl non risus fermentum consequat eget malesuada. Pretium quis purus nec neque et risus aenean! Rutrum commodo lorem pellentesque nec imperdiet nec eu ut; Est varius sed a placerat curabitur cursus. Sit donec erat hendrerit mauris hendrerit. Sed aliquam penatibus imperdiet vivamus. Morbi parturient vel aliquet urna phasellus tincidunt id. Nec duis eget venenatis fusce nunc sem justo diam euismod. Lacinia diam pretium hendrerit metus vitae facilisis nisl pharetra nam. Vitae ultrices neque turpis dui nulla tincidunt phasellus nam eros;</p>\n\n<p>Nam urna rutrum bibendum placerat ut sed elit cum venenatis nullam non. Non venenatis lacinia non venenatis pulvinar. Nam eget non ut semper eget egestas ac ultrices placerat rutrum: Urna accumsan in diam sit massa urna aliquam pellentesque elementum. Congue nisl phasellus consequat et lacinia sodales iaculis lacus cras vestibulum, Bibendum varius metus lectus odio sed placerat at velit lorem porta: Eros neque faucibus ut augue lobortis. Est velit at ligula nec dapibus risus quis. Placerat mus pharetra parturient ut quis ipsum dui. Nibh nisl dis dui phasellus facilisis eu eros nec in dignissim.</p>\n\n<p>Sed nec volutpat at aliquam sodales luctus? Lobortis sed vitae duis pharetra dui? Lacus laoreet purus sodales nec gravida dictum erat; Malesuada dignissim dolor penatibus cras sit eget risus; Turpis faucibus pharetra nibh interdum in sit suscipit nec nulla eget; Amet amet quam cras pretium sociis ut; Dignissim non nullam sed bibendum magna sodales nec consequat laoreet suspendisse. Nunc risus lacus cursus enim nisl dolor id nunc sit amet.</p>\n\n<p>Quis vel lacus non lorem venenatis at dignissim dolor justo sociis vestibulum. Euismod sollicitudin arcu sit nam vel. Dignissim tempor mauris venenatis sapien ligula nam! Mattis nisl proin pretium placerat nunc quis est bibendum faucibus adipiscing. Eu vitae urna metus pellentesque at, Nisl nunc sagittis interdum eget fusce dui commodo id non sodales! Consectetur interdum lacus nec at lacus nisl sapien pharetra sapien justo. Ut ligula sem mauris risus a non hendrerit non. Donec aliquet amet ante nisl elit porttitor. Gravida donec vestibulum vestibulum vitae leo non mattis at adipiscing neque!</p>\n', 'Boyah! '' och " och BREAK''*´^1ÜŒˆ`Y', 0);
INSERT INTO `bliss_contents` VALUES(5, 0, 0, 'Testar', '<p>Mauris placerat dui urna nam eget metus. Leo rutrum dui nisl parturient fusce. At dignissim neque diam suscipit sodales sed molestie a posuere dolor vitae; Dolor dignissim non neque sit id. Sed consequat lacinia urna blandit. Phasellus at eget aenean luctus pharetra amet mollis turpis, Ipsum neque justo at vestibulum lorem pulvinar dis dolor nulla est: Lacus fermentum phasellus nullam varius vestibulum eu risus erat feugiat etiam sit? Porta dui congue phasellus mauris neque nec erat, Pharetra justo convallis arcu tincidunt donec lorem elit? Hendrerit risus nec eu at suspendisse blandit. Ut morbi tempor at montes vestibulum? Morbi vitae nunc eu consectetur adipiscing interdum erat.</p>\n\n<p>Euismod lorem erat sit nam bibendum id cras sed dictum urna suspendisse. Purus nec enim ligula tincidunt neque adipiscing feugiat tincidunt, Elit in leo auctor lectus; Quis urna donec mollis erat. Odio sollicitudin consectetur nam sem leo neque venenatis cursus enim nisl massa; Urna consectetur consequat suspendisse nulla pretium nisl. Natoque consectetur lorem sed varius neque amet rutrum maecenas pellentesque? In massa aliquam sem arcu tincidunt urna donec nisl sodales.</p>\n\n<p>Bibendum vitae ultrices sodales dui. Turpis aenean enim in erat orci aenean: Et iaculis libero sit ligula velit dui fusce mollis facilisis? Venenatis vel tellus donec in sollicitudin lorem? Et mollis aliquet eros lorem facilisis massa fermentum cum: Velit venenatis blandit vivamus ligula ante ligula nisl vestibulum adipiscing faucibus; Dignissim consequat convallis est donec velit nibh pharetra dui nunc. Sed magnis risus interdum pretium non interdum. Quam placerat a ligula est erat faucibus phasellus vitae pharetra! Mauris enim mauris nec porta aliquam vitae at eget risus.</p>\n\n<p>Tristique dui quis bibendum sit sapien est id donec donec nam lacus. Fusce sed erat sit sit nisi lacus! A dolor consequat a amet phasellus? Posuere nisl bibendum at aliquet. Vestibulum lacinia vestibulum a a dui ultrices at mauris vestibulum risus. Placerat eget cursus interdum nam erat ut tempor cursus est aenean aliquam. Pharetra pharetra amet libero volutpat interdum non phasellus sapien est non facilisis. Augue sagittis non venenatis dui, Hendrerit dapibus diam eget eros lectus turpis? Vitae risus a consequat eget: Pellentesque a sagittis sollicitudin feugiat neque vestibulum.</p>\n\n<p>Vestibulum id turpis nec eget pellentesque urna nec enim eget. Nulla lorem sed lorem nec porta ipsum faucibus leo porta? Consequat fermentum lacus urna rhoncus facilisis in feugiat natoque aenean. Sed suscipit sodales in rhoncus rhoncus eros bibendum luctus natoque. Consectetur phasellus urna a ante vitae sed ipsum hendrerit vitae eu, Hendrerit luctus lorem accumsan amet lacus convallis facilisis suspendisse; Sem non ipsum amet dignissim nisl in a dui lacus eu ultrices, Interdum lacus nunc metus nibh penatibus metus sed volutpat; Purus lacus fermentum egestas mattis phasellus: Nulla vivamus venenatis mollis justo lacus mollis, Nunc faucibus adipiscing condimentum non ridiculus? Eu quis varius lorem malesuada varius eros lacus id eget consectetur ullamcorper. Non vestibulum nascetur metus vel vitae donec nibh pretium. Nunc id adipiscing at parturient. Neque vitae rutrum vivamus phasellus ultricies.</p>\n', '', 0);
INSERT INTO `bliss_contents` VALUES(6, 0, 0, 'testar', 'Med nya Kohana 3.3', '', 0);
INSERT INTO `bliss_contents` VALUES(10, 0, 0, 'Ouya', '', '', 0);
INSERT INTO `bliss_contents` VALUES(14, 0, 0, '"Gônk!" åäöÅÄÖ d''Or!', '"Gônk!" åäöÅÄÖ d''Or!', '', 0);
INSERT INTO `bliss_contents` VALUES(15, 0, 0, '汉语/漢語 Hànyǔ, 华语/華語 Huáyǔ, or 中文 Zhōngwén', '汉语/漢語 Hànyǔ, 华语/華語 Huáyǔ, or 中文 Zhōngwén', '汉语/漢語 Hànyǔ, 华语/華語 Huáyǔ, or 中文 Zhōngwén', 0);
INSERT INTO `bliss_contents` VALUES(16, 0, 0, 'ورود · تنظیمات جستجو · تاریخچه ی شبکه. فارسی. جستجوی پیشرفتهابزار', '<p>جستجو &middot; تصاویر &middot; YouTube &middot; Gmail &middot; ترجمه شود &middot; تلفن همراه &middot; بلاگر. Account Options. ورود &middot; تنظیمات جستجو &middot; تاریخچه ی شبکه. فارسی. جستجوی پیشرفتهابزار ... درباره Google&lrm; - تصاویر&lrm; - ترجمه&lrm;</p>\n\n<h2>Woot!</h2>\n\n<p>Lorem ipsum...</p>\n', '', 0);
INSERT INTO `bliss_contents` VALUES(17, 0, 0, 'Lördag idag va?', '<div id="lorem">\n<p>In magnis ipsum sed vel: Sit sapien integer phasellus fermentum eget! Erat ipsum magnis eros dolor nibh erat dis nec nam. Leo suscipit orci at eleifend nam in in sapien sagittis elit. Romanus eunt domus. Suspendisse nunc erat dolor nibh convallis dui phasellus: Porta non neque porttitor nec fusce sollicitudin lorem convallis lectus justo. Accumsan porta dignissim proin non placerat. Dolor nibh arcu tincidunt ut pulvinar urna amet. Erat nunc nullam sed ut fusce egestas,</p>\n\n<p>Duis gravida vestibulum porta sollicitudin enim nam? Venenatis venenatis vivamus suspendisse elementum mollis? Tellus accumsan augue et cursus laoreet nulla: Dignissim lacus vitae nisl non risus fermentum consequat eget malesuada. Pretium quis purus nec neque et risus aenean! Rutrum commodo lorem pellentesque nec imperdiet nec eu ut; Est varius sed a placerat curabitur cursus. Sit donec erat hendrerit mauris hendrerit. Sed aliquam penatibus imperdiet vivamus. Morbi parturient vel aliquet urna phasellus tincidunt id. Nec duis eget venenatis fusce nunc sem justo diam euismod. Lacinia diam pretium hendrerit metus vitae facilisis nisl pharetra nam. Vitae ultrices neque turpis dui nulla tincidunt phasellus nam eros;</p>\n\n<p>Nam urna rutrum bibendum placerat ut sed elit cum venenatis nullam non. Non venenatis lacinia non venenatis pulvinar. Nam eget non ut semper eget egestas ac ultrices placerat rutrum: Urna accumsan in diam sit massa urna aliquam pellentesque elementum. Congue nisl phasellus consequat et lacinia sodales iaculis lacus cras vestibulum, Bibendum varius metus lectus odio sed placerat at velit lorem porta: Eros neque faucibus ut augue lobortis. Est velit at ligula nec dapibus risus quis. Placerat mus pharetra parturient ut quis ipsum dui. Nibh nisl dis dui phasellus facilisis eu eros nec in dignissim.</p>\n\n<p>Sed nec volutpat at aliquam sodales luctus? Lobortis sed vitae duis pharetra dui? Lacus laoreet purus sodales nec gravida dictum erat; Malesuada dignissim dolor penatibus cras sit eget risus; Turpis faucibus pharetra nibh interdum in sit suscipit nec nulla eget; Amet amet quam cras pretium sociis ut; Dignissim non nullam sed bibendum magna sodales nec consequat laoreet suspendisse. Nunc risus lacus cursus enim nisl dolor id nunc sit amet.</p>\n\n<p>Quis vel lacus non lorem venenatis at dignissim dolor justo sociis vestibulum. Euismod sollicitudin arcu sit nam vel. Dignissim tempor mauris venenatis sapien ligula nam! Mattis nisl proin pretium placerat nunc quis est bibendum faucibus adipiscing. Eu vitae urna metus pellentesque at, Nisl nunc sagittis interdum eget fusce dui commodo id non sodales! Consectetur interdum lacus nec at lacus nisl sapien pharetra sapien justo. Ut ligula sem mauris risus a non hendrerit non. Donec aliquet amet ante nisl elit porttitor. Gravida donec vestibulum vestibulum vitae leo non mattis at adipiscing neque!</p>\n\n<div>&nbsp;</div>\n</div>\n', '', 0);
INSERT INTO `bliss_contents` VALUES(18, 0, 0, 'Sweet! ', '<p>Fixa s&aring; att det funkar att visa inneh&aring;ll nu bara...</p>\n', '', 0);
INSERT INTO `bliss_contents` VALUES(19, 0, 0, 'Att göra', '<ul>\n	<li>Kunna visa inneh&aring;ll</li>\n	<li>Bygg p&aring; nya databasmodellen f&ouml;r <em>content</em></li>\n</ul>\n', '', 0);
INSERT INTO `bliss_contents` VALUES(20, 0, 0, 'Nytt innehåll igen...', '<p>Testar s&aring; att det funkar fortfarande.</p>\n', '', 0);
INSERT INTO `bliss_contents` VALUES(24, 0, 0, 'Lorem2', '<p>Hepp?&nbsp;</p>\n\n<p>In blandit porta luctus dui accumsan eget aliquam sed sed; Gravida ipsum mauris elit quam non sed? Eu amet a mauris sem hendrerit consequat eros sit. Ipsum vitae ligula tincidunt sit eget purus porta. Amet leo mauris faucibus dolor pulvinar. Amet neque interdum arcu cras orci. Magna rhoncus massa nam vel varius? Tristique pulvinar at dignissim lacus placerat maecenas nec sed leo: Accumsan amet felis tortor phasellus: Urna arcu massa eget purus ipsum nunc euismod dignissim vitae non.</p>\n\n<p>Consectetur erat sit nunc quis elementum ipsum phasellus. Odio nec nunc eget lacinia at ullamcorper sed? Nulla porta curabitur ut nec diam erat penatibus sed mattis tristique. Mus dui porttitor ligula adipiscing imperdiet. Metus donec risus proin iaculis. Dignissim non vivamus diam dignissim lacus: Nec non rhoncus sociis fermentum nibh dui vel libero, Lorem eget tincidunt nec rutrum turpis cras faucibus.</p>\n\n<p>Est dolor urna at quis placerat? Ipsum rutrum ipsum luctus commodo metus. Est eu sed lacus urna ultricies bibendum nunc donec risus pellentesque: Non amet eleifend neque dui. Phasellus est phasellus tempor elementum accumsan sed vitae luctus, A pharetra quis purus aliquam nec ante vitae fermentum suscipit. Lectus a diam neque vitae lacus tincidunt sit nunc dis lacus: Bibendum phasellus ligula ipsum posuere maecenas adipiscing.</p>\n\n<p>Pharetra porta eget lorem non risus vivamus; Nisi fermentum at facilisis sed varius dictum ligula. Quis amet neque neque non massa nibh! Risus purus vitae rhoncus massa lacus ut! Nam justo feugiat blandit faucibus nisi purus congue aliquet purus suspendisse sodales! Sed mi leo sagittis nulla pharetra sit non volutpat. Augue non faucibus sodales tincidunt; Interdum nulla id lacinia hendrerit mollis imperdiet ante. Ullamcorper ut amet fermentum eget etiam sit,</p>\n\n<p>Proin nulla imperdiet justo accumsan consequat sem cursus. Lacus arcu ligula justo luctus metus lacinia ullamcorper aenean et pharetra neque, Dui adipiscing posuere sit felis urna sit dolor. Eros sodales eleifend venenatis sociis: Ut elit mauris mus faucibus interdum rhoncus, Odio vel mauris sit varius vitae. Cursus amet urna risus rutrum vivamus varius eu neque nam vestibulum molestie. Tincidunt mus mollis hendrerit amet lacus eu: Ac adipiscing consequat libero proin sapien dictum dignissim. Enim convallis eget adipiscing lacus luctus: Tristique est a convallis velit tellus facilisis malesuada purus porta. Eu magna sit leo nam luctus lacus. At etiam luctus luctus pharetra leo a fermentum.</p>\n', '', 0);
INSERT INTO `bliss_contents` VALUES(25, 0, 0, 'Snart pizza?', '<p>Condimentum consectetur cursus ut dui; Dui nisl nunc egestas id ipsum neque. Quis lorem sit nisl gravida convallis ipsum; Luctus velit justo at tellus sagittis tellus bibendum, Pharetra aliquam turpis aenean tincidunt tincidunt in parturient iaculis, At tristique mauris tellus non risus pharetra neque, Eros nisl neque et dolor adipiscing nisi dui eros aliquam nascetur dictum. Fermentum eget massa leo quisque risus! Mi urna mauris ut nec non suspendisse. At nec non lectus elementum massa: Consequat phasellus dui rutrum vestibulum; Donec odio vel cursus montes.</p>\n\n<p>Aliquam rutrum phasellus non morbi pulvinar. Nisl ultrices porta velit volutpat nec ut curabitur dolor bibendum viverra. Enim pellentesque vel sodales urna erat mollis metus aliquam varius: Ligula mauris tortor dolor interdum tortor in vitae justo: Leo suscipit facilisis hendrerit elit eget orci; Bibendum massa sed nulla nibh eget vestibulum consequat non cras suspendisse. Suspendisse interdum nisl enim donec viverra porttitor. Leo elit ante duis facilisis risus eu accumsan urna pretium felis urna. Tellus pulvinar enim risus dui sit aliquam erat justo imperdiet arcu pretium? Nunc nec nunc erat rutrum turpis dui? Curabitur accumsan id sed ligula sed mauris mauris donec erat amet; At eget rutrum vitae donec volutpat fermentum.</p>\n\n<p>Nec enim lorem interdum a tellus risus sit varius fusce erat: Risus sit nunc pulvinar id tincidunt orci donec facilisis. Erat amet iaculis fermentum erat duis eu, At lacus sit sit consequat urna placerat hendrerit aenean aliquam! Integer nisi libero augue feugiat risus nisl blandit eget justo sapien condimentum. Gravida enim nullam sit mauris cursus est enim mollis sit dui dolor; Nec tincidunt ut vel adipiscing non in donec suspendisse dignissim phasellus. Rutrum leo urna fermentum in cras et hendrerit nullam quis ut pretium. Urna pulvinar amet convallis convallis eu;</p>\n\n<p>Leo tincidunt tincidunt placerat sed odio quis in; Enim phasellus enim sit lectus; Pulvinar lectus ullamcorper fermentum congue dolor neque cras aliquam dui nisl? Eleifend leo luctus non nec aliquam. Arcu est tortor erat purus donec hendrerit. Erat nec phasellus posuere imperdiet leo sociis: Luctus quis lacus id bibendum. Velit eu convallis leo amet phasellus at: Laoreet dignissim nisl est sed auctor dignissim lacus ac consectetur. Mauris feugiat nec in donec vitae non nisl lacinia erat? Turpis varius mattis ipsum donec nec: Sed quis pretium id rhoncus.</p>\n', 'atet', 0);
INSERT INTO `bliss_contents` VALUES(26, 0, 2, 'Woho!', '<p>Nu du!</p>\n', '', 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_content_items`
--

CREATE TABLE `bliss_content_items` (
  `content_item_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) unsigned NOT NULL,
  `content_parent` int(10) unsigned NOT NULL DEFAULT '0',
  `language_id` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `content_status` varchar(20) DEFAULT NULL,
  `content_revision` tinyint(5) unsigned NOT NULL DEFAULT '1',
  `content_title` varchar(255) DEFAULT NULL,
  `content_alias` varchar(255) DEFAULT NULL,
  `content_excerpt` text,
  `content_text` mediumtext,
  `content_created_date` datetime DEFAULT NULL,
  `content_modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`content_item_id`),
  KEY `ix_content_language_status` (`content_id`,`language_id`,`content_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `bliss_content_items`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_content_meta`
--

CREATE TABLE `bliss_content_meta` (
  `meta_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) unsigned NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `meta_value` mediumtext NOT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `ix_content_id` (`content_id`),
  KEY `ix_meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `bliss_content_meta`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_content_terms`
--

CREATE TABLE `bliss_content_terms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) unsigned DEFAULT NULL,
  `term_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_content_id` (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `bliss_content_terms`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_content_types`
--

CREATE TABLE `bliss_content_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `configuration` text NOT NULL,
  `display` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Data i tabell `bliss_content_types`
--

INSERT INTO `bliss_content_types` VALUES(1, 0, 'Page23', 'page', NULL, 'Vilka fält som ligger var i ADMIN.', 'Koden för att visa här...');
INSERT INTO `bliss_content_types` VALUES(3, 0, 'Test', 'test', NULL, '', NULL);
INSERT INTO `bliss_content_types` VALUES(6, 0, 'asdf', 'asdf', NULL, '', NULL);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_options`
--

CREATE TABLE `bliss_options` (
  `option_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subsite_id` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `option_name` varchar(255) NOT NULL,
  `option_value` text,
  `autoload` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Data i tabell `bliss_options`
--

INSERT INTO `bliss_options` VALUES(1, 0, 'time_zone', 'CET', 1);
INSERT INTO `bliss_options` VALUES(2, 0, 'site_url', 'http://localhost/kohana-project/', 1);
INSERT INTO `bliss_options` VALUES(3, 0, 'site_name', 'Kohana Project', 1);
INSERT INTO `bliss_options` VALUES(4, 0, 'test22', 'test22', 0);
INSERT INTO `bliss_options` VALUES(5, 0, 'language', 'en-us', 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_roles`
--

CREATE TABLE `bliss_roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Data i tabell `bliss_roles`
--

INSERT INTO `bliss_roles` VALUES(1, 'login', 'Login privileges, granted after account confirmation');
INSERT INTO `bliss_roles` VALUES(2, 'admin', 'Administrative user, has access to everything.');

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_roles_users`
--

CREATE TABLE `bliss_roles_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data i tabell `bliss_roles_users`
--

INSERT INTO `bliss_roles_users` VALUES(1, 1);
INSERT INTO `bliss_roles_users` VALUES(6, 1);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_term_taxonomy`
--

CREATE TABLE `bliss_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Data i tabell `bliss_term_taxonomy`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_users`
--

CREATE TABLE `bliss_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(127) NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `username_nice` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `salt` varchar(64) NOT NULL,
  `logins` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`),
  UNIQUE KEY `uniq_username_nice` (`username_nice`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Data i tabell `bliss_users`
--

INSERT INTO `bliss_users` VALUES(1, 'anders@bobolo.se', 'admin', 'admin', '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 47, '2013-01-01 14:55:28');
INSERT INTO `bliss_users` VALUES(6, 'anders.dahlgren@gmail.com', 'member', '', '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 0, NULL);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_user_tokens`
--

CREATE TABLE `bliss_user_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(40) NOT NULL,
  `type` varchar(100) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Data i tabell `bliss_user_tokens`
--

INSERT INTO `bliss_user_tokens` VALUES(1, 1, '1d70d59dc08053dfd41cec41831688011ecbe5c5', '087401c683785feac7feddb1d98a08bb35ded5dd', '', 0, 1358005191);

--
-- Restriktioner för dumpade tabeller
--

--
-- Restriktioner för tabell `bliss_roles_users`
--
ALTER TABLE `bliss_roles_users`
  ADD CONSTRAINT `bliss_roles_users_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `bliss_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bliss_roles_users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `bliss_roles` (`id`) ON DELETE CASCADE;

--
-- Restriktioner för tabell `bliss_user_tokens`
--
ALTER TABLE `bliss_user_tokens`
  ADD CONSTRAINT `bliss_user_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `bliss_users` (`id`) ON DELETE CASCADE;
