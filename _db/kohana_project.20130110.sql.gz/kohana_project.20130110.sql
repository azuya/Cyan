-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Värd: localhost
-- Skapad: 10 januari 2013 kl 19:42
-- Serverversion: 5.5.9
-- PHP-version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databas: `kohana_project`
--

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_comments`
--

CREATE TABLE `bliss_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) NOT NULL,
  `comment` text NOT NULL,
  `time` datetime NOT NULL,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_content` (`content_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Data i tabell `bliss_comments`
--

INSERT INTO `bliss_comments` VALUES(1, 5, 'Testar!', '0000-00-00 00:00:00', 'Anders', 'anders@bobolo.se');
INSERT INTO `bliss_comments` VALUES(2, 5, 'Testar!', '0000-00-00 00:00:00', 'Anders', 'anders@bobolo.se');
INSERT INTO `bliss_comments` VALUES(3, 5, 'WEeeho!', '0000-00-00 00:00:00', 'Kalle Balle', '');
INSERT INTO `bliss_comments` VALUES(4, 5, 'Kommentar!', '0000-00-00 00:00:00', 'Namn', 'Epost');

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_content`
--

CREATE TABLE `bliss_content` (
  `content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_parent_content_id` int(10) unsigned DEFAULT NULL,
  `content_type_id` varchar(40) DEFAULT NULL,
  `content_visible` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `content_canonical_url` varchar(255) DEFAULT NULL,
  `content_order` int(10) unsigned NOT NULL DEFAULT '0',
  `content_password` varchar(40) DEFAULT NULL,
  `content_mime_type` varchar(50) DEFAULT NULL,
  `content_author` int(10) unsigned DEFAULT NULL,
  `content_start_date` datetime DEFAULT NULL,
  `content_end_date` datetime DEFAULT NULL,
  `content_comment_allowed` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `content_rating_allowed` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `content_like_allowed` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `content_comment_count` int(10) unsigned NOT NULL DEFAULT '0',
  `content_rating` float unsigned NOT NULL DEFAULT '0',
  `content_rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `content_like_count` int(10) unsigned NOT NULL DEFAULT '0',
  `subsite_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`),
  KEY `ix_content_type_id` (`content_type_id`),
  KEY `ix_content_parent_id` (`content_parent_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `bliss_content`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_content_items`
--

CREATE TABLE `bliss_content_items` (
  `content_item_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) unsigned NOT NULL,
  `content_parent` int(10) unsigned NOT NULL DEFAULT '0',
  `language_id` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `content_status` varchar(20) DEFAULT NULL,
  `content_revision` tinyint(5) unsigned NOT NULL DEFAULT '1',
  `content_title` varchar(255) DEFAULT NULL,
  `content_alias` varchar(255) DEFAULT NULL,
  `content_excerpt` text,
  `content_text` mediumtext,
  `content_created_date` datetime DEFAULT NULL,
  `content_modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`content_item_id`),
  KEY `ix_content_language_status` (`content_id`,`language_id`,`content_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `bliss_content_items`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_content_meta`
--

CREATE TABLE `bliss_content_meta` (
  `meta_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) unsigned NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `meta_value` mediumtext NOT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `ix_content_id` (`content_id`),
  KEY `ix_meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `bliss_content_meta`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_content_terms`
--

CREATE TABLE `bliss_content_terms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) unsigned DEFAULT NULL,
  `term_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_content_id` (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `bliss_content_terms`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_options`
--

CREATE TABLE `bliss_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subsite_id` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `option_name` varchar(255) NOT NULL,
  `option_value` text,
  `autoload` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Data i tabell `bliss_options`
--

INSERT INTO `bliss_options` VALUES(1, 0, 'time_zone', 'CET', 1);
INSERT INTO `bliss_options` VALUES(2, 0, 'site_url', 'http://localhost/kohana-project/', 1);
INSERT INTO `bliss_options` VALUES(3, 0, 'site_name', 'Kohana Project!', 1);
INSERT INTO `bliss_options` VALUES(4, 0, 'fouxxx', 'test223', 0);
INSERT INTO `bliss_options` VALUES(5, 0, 'language', 'en-us', 0);
INSERT INTO `bliss_options` VALUES(6, 0, 'en till', 'hej!', 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_posts`
--

CREATE TABLE `bliss_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `type_id` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `excerpt` text,
  `content` text,
  `created_date` datetime NOT NULL,
  `modified_date` datetime DEFAULT NULL,
  `testar` varchar(100) DEFAULT NULL,
  `author_id` int(10) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=86 ;

--
-- Data i tabell `bliss_posts`
--

INSERT INTO `bliss_posts` VALUES(3, 0, 1, '2.Boyah! '' och " och BREAK''*´^1ÜŒˆ`Y', NULL, '<p>2Boyah! &#39; och &quot; och BREAK&#39;*&acute;^1&Uuml;&OElig;&circ;`Y!1111</p>\n\n<p>In magnis ipsum sed vel: Sit sapien integer phasellus fermentum eget! Erat ipsum magnis eros dolor nibh erat dis nec nam. Leo suscipit orci at eleifend nam in in sapien sagittis elit. Romanus eunt domus. Suspendisse nunc erat dolor nibh convallis dui phasellus: Porta non neque porttitor nec fusce sollicitudin lorem convallis lectus justo. Accumsan porta dignissim proin non placerat. Dolor nibh arcu tincidunt ut pulvinar urna amet. Erat nunc nullam sed ut fusce egestas,</p>\n\n<p>Duis gravida vestibulum porta sollicitudin enim nam? Venenatis venenatis vivamus suspendisse elementum mollis? Tellus accumsan augue et cursus laoreet nulla: Dignissim lacus vitae nisl non risus fermentum consequat eget malesuada. Pretium quis purus nec neque et risus aenean! Rutrum commodo lorem pellentesque nec imperdiet nec eu ut; Est varius sed a placerat curabitur cursus. Sit donec erat hendrerit mauris hendrerit. Sed aliquam penatibus imperdiet vivamus. Morbi parturient vel aliquet urna phasellus tincidunt id. Nec duis eget venenatis fusce nunc sem justo diam euismod. Lacinia diam pretium hendrerit metus vitae facilisis nisl pharetra nam. Vitae ultrices neque turpis dui nulla tincidunt phasellus nam eros;</p>\n\n<p>Nam urna rutrum bibendum placerat ut sed elit cum venenatis nullam non. Non venenatis lacinia non venenatis pulvinar. Nam eget non ut semper eget egestas ac ultrices placerat rutrum: Urna accumsan in diam sit massa urna aliquam pellentesque elementum. Congue nisl phasellus consequat et lacinia sodales iaculis lacus cras vestibulum, Bibendum varius metus lectus odio sed placerat at velit lorem porta: Eros neque faucibus ut augue lobortis. Est velit at ligula nec dapibus risus quis. Placerat mus pharetra parturient ut quis ipsum dui. Nibh nisl dis dui phasellus facilisis eu eros nec in dignissim.</p>\n\n<p>Sed nec volutpat at aliquam sodales luctus? Lobortis sed vitae duis pharetra dui? Lacus laoreet purus sodales nec gravida dictum erat; Malesuada dignissim dolor penatibus cras sit eget risus; Turpis faucibus pharetra nibh interdum in sit suscipit nec nulla eget; Amet amet quam cras pretium sociis ut; Dignissim non nullam sed bibendum magna sodales nec consequat laoreet suspendisse. Nunc risus lacus cursus enim nisl dolor id nunc sit amet.</p>\n\n<p>Quis vel lacus non lorem venenatis at dignissim dolor justo sociis vestibulum. Euismod sollicitudin arcu sit nam vel. Dignissim tempor mauris venenatis sapien ligula nam! Mattis nisl proin pretium placerat nunc quis est bibendum faucibus adipiscing. Eu vitae urna metus pellentesque at, Nisl nunc sagittis interdum eget fusce dui commodo id non sodales! Consectetur interdum lacus nec at lacus nisl sapien pharetra sapien justo. Ut ligula sem mauris risus a non hendrerit non. Donec aliquet amet ante nisl elit porttitor. Gravida donec vestibulum vestibulum vitae leo non mattis at adipiscing neque!</p>\n', '0000-00-00 00:00:00', '2013-01-07 20:10:10', 'Boyah! '' och " och BREAK''*´^1ÜŒˆ`Y', 20, 1);
INSERT INTO `bliss_posts` VALUES(5, 0, 0, 'Testar', NULL, '<p>Mauris placerat dui urna nam eget metus. Leo rutrum dui nisl parturient fusce. At dignissim neque diam suscipit sodales sed molestie a posuere dolor vitae; Dolor dignissim non neque sit id. Sed consequat lacinia urna blandit. Phasellus at eget aenean luctus pharetra amet mollis turpis, Ipsum neque justo at vestibulum lorem pulvinar dis dolor nulla est: Lacus fermentum phasellus nullam varius vestibulum eu risus erat feugiat etiam sit? Porta dui congue phasellus mauris neque nec erat, Pharetra justo convallis arcu tincidunt donec lorem elit? Hendrerit risus nec eu at suspendisse blandit. Ut morbi tempor at montes vestibulum? Morbi vitae nunc eu consectetur adipiscing interdum erat.</p>\n\n<p>Euismod lorem erat sit nam bibendum id cras sed dictum urna suspendisse. Purus nec enim ligula tincidunt neque adipiscing feugiat tincidunt, Elit in leo auctor lectus; Quis urna donec mollis erat. Odio sollicitudin consectetur nam sem leo neque venenatis cursus enim nisl massa; Urna consectetur consequat suspendisse nulla pretium nisl. Natoque consectetur lorem sed varius neque amet rutrum maecenas pellentesque? In massa aliquam sem arcu tincidunt urna donec nisl sodales.</p>\n\n<p>Bibendum vitae ultrices sodales dui. Turpis aenean enim in erat orci aenean: Et iaculis libero sit ligula velit dui fusce mollis facilisis? Venenatis vel tellus donec in sollicitudin lorem? Et mollis aliquet eros lorem facilisis massa fermentum cum: Velit venenatis blandit vivamus ligula ante ligula nisl vestibulum adipiscing faucibus; Dignissim consequat convallis est donec velit nibh pharetra dui nunc. Sed magnis risus interdum pretium non interdum. Quam placerat a ligula est erat faucibus phasellus vitae pharetra! Mauris enim mauris nec porta aliquam vitae at eget risus.</p>\n\n<p>Tristique dui quis bibendum sit sapien est id donec donec nam lacus. Fusce sed erat sit sit nisi lacus! A dolor consequat a amet phasellus? Posuere nisl bibendum at aliquet. Vestibulum lacinia vestibulum a a dui ultrices at mauris vestibulum risus. Placerat eget cursus interdum nam erat ut tempor cursus est aenean aliquam. Pharetra pharetra amet libero volutpat interdum non phasellus sapien est non facilisis. Augue sagittis non venenatis dui, Hendrerit dapibus diam eget eros lectus turpis? Vitae risus a consequat eget: Pellentesque a sagittis sollicitudin feugiat neque vestibulum.</p>\n\n<p>Vestibulum id turpis nec eget pellentesque urna nec enim eget. Nulla lorem sed lorem nec porta ipsum faucibus leo porta? Consequat fermentum lacus urna rhoncus facilisis in feugiat natoque aenean. Sed suscipit sodales in rhoncus rhoncus eros bibendum luctus natoque. Consectetur phasellus urna a ante vitae sed ipsum hendrerit vitae eu, Hendrerit luctus lorem accumsan amet lacus convallis facilisis suspendisse; Sem non ipsum amet dignissim nisl in a dui lacus eu ultrices, Interdum lacus nunc metus nibh penatibus metus sed volutpat; Purus lacus fermentum egestas mattis phasellus: Nulla vivamus venenatis mollis justo lacus mollis, Nunc faucibus adipiscing condimentum non ridiculus? Eu quis varius lorem malesuada varius eros lacus id eget consectetur ullamcorper. Non vestibulum nascetur metus vel vitae donec nibh pretium. Nunc id adipiscing at parturient. Neque vitae rutrum vivamus phasellus ultricies.</p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(6, 0, 0, 'testar', NULL, '<p>Med nya Kohana 3.3</p>\n', '0000-00-00 00:00:00', '2013-01-06 21:12:24', '', 19, 0);
INSERT INTO `bliss_posts` VALUES(10, 0, 0, 'Ouya', NULL, '', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(14, 0, 0, '"Gônk!" åäöÅÄÖ d''Or!', NULL, '<p>&quot;G&ocirc;nk!&quot; &aring;&auml;&ouml;&Aring;&Auml;&Ouml; d&#39;Or!</p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(15, 0, 0, '汉语/漢語 Hànyǔ, 华语/華語 Huáyǔ, or 中文 Zhōngwén', NULL, '汉语/漢語 Hànyǔ, 华语/華語 Huáyǔ, or 中文 Zhōngwén', '0000-00-00 00:00:00', NULL, '汉语/漢語 Hànyǔ, 华语/華語 Huáyǔ, or 中文 Zhōngwén', 1, 1);
INSERT INTO `bliss_posts` VALUES(16, 0, 0, 'ورود · تنظیمات جستجو · تاریخچه ی شبکه. فارسی. جستجوی پیشرفتهابزار', NULL, '<p>جستجو &middot; تصاویر &middot; YouTube &middot; Gmail &middot; ترجمه شود &middot; تلفن همراه &middot; بلاگر. Account Options. ورود &middot; تنظیمات جستجو &middot; تاریخچه ی شبکه. فارسی. جستجوی پیشرفتهابزار ... درباره Google&lrm; - تصاویر&lrm; - ترجمه&lrm;</p>\n\n<h2>Woot!</h2>\n\n<p>Lorem ipsum...</p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(17, 0, 0, 'Lördag idag va?', NULL, '<div id="lorem">\n<p>In magnis ipsum sed vel: Sit sapien integer phasellus fermentum eget! Erat ipsum magnis eros dolor nibh erat dis nec nam. Leo suscipit orci at eleifend nam in in sapien sagittis elit. Romanus eunt domus. Suspendisse nunc erat dolor nibh convallis dui phasellus: Porta non neque porttitor nec fusce sollicitudin lorem convallis lectus justo. Accumsan porta dignissim proin non placerat. Dolor nibh arcu tincidunt ut pulvinar urna amet. Erat nunc nullam sed ut fusce egestas,</p>\n\n<p>Duis gravida vestibulum porta sollicitudin enim nam? Venenatis venenatis vivamus suspendisse elementum mollis? Tellus accumsan augue et cursus laoreet nulla: Dignissim lacus vitae nisl non risus fermentum consequat eget malesuada. Pretium quis purus nec neque et risus aenean! Rutrum commodo lorem pellentesque nec imperdiet nec eu ut; Est varius sed a placerat curabitur cursus. Sit donec erat hendrerit mauris hendrerit. Sed aliquam penatibus imperdiet vivamus. Morbi parturient vel aliquet urna phasellus tincidunt id. Nec duis eget venenatis fusce nunc sem justo diam euismod. Lacinia diam pretium hendrerit metus vitae facilisis nisl pharetra nam. Vitae ultrices neque turpis dui nulla tincidunt phasellus nam eros;</p>\n\n<p>Nam urna rutrum bibendum placerat ut sed elit cum venenatis nullam non. Non venenatis lacinia non venenatis pulvinar. Nam eget non ut semper eget egestas ac ultrices placerat rutrum: Urna accumsan in diam sit massa urna aliquam pellentesque elementum. Congue nisl phasellus consequat et lacinia sodales iaculis lacus cras vestibulum, Bibendum varius metus lectus odio sed placerat at velit lorem porta: Eros neque faucibus ut augue lobortis. Est velit at ligula nec dapibus risus quis. Placerat mus pharetra parturient ut quis ipsum dui. Nibh nisl dis dui phasellus facilisis eu eros nec in dignissim.</p>\n\n<p>Sed nec volutpat at aliquam sodales luctus? Lobortis sed vitae duis pharetra dui? Lacus laoreet purus sodales nec gravida dictum erat; Malesuada dignissim dolor penatibus cras sit eget risus; Turpis faucibus pharetra nibh interdum in sit suscipit nec nulla eget; Amet amet quam cras pretium sociis ut; Dignissim non nullam sed bibendum magna sodales nec consequat laoreet suspendisse. Nunc risus lacus cursus enim nisl dolor id nunc sit amet.</p>\n\n<p>Quis vel lacus non lorem venenatis at dignissim dolor justo sociis vestibulum. Euismod sollicitudin arcu sit nam vel. Dignissim tempor mauris venenatis sapien ligula nam! Mattis nisl proin pretium placerat nunc quis est bibendum faucibus adipiscing. Eu vitae urna metus pellentesque at, Nisl nunc sagittis interdum eget fusce dui commodo id non sodales! Consectetur interdum lacus nec at lacus nisl sapien pharetra sapien justo. Ut ligula sem mauris risus a non hendrerit non. Donec aliquet amet ante nisl elit porttitor. Gravida donec vestibulum vestibulum vitae leo non mattis at adipiscing neque!</p>\n\n<div>&nbsp;</div>\n</div>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(18, 0, 3, 'Sweet! ', NULL, '<p>Fixa s&aring; att det funkar att visa inneh&aring;ll nu bara...</p>\n\n<p>Non porta eget arcu justo dictum ipsum eros; Id consectetur hendrerit id nibh placerat diam iaculis elit dui tristique. Dui lorem lectus volutpat cursus sodales fusce risus molestie rutrum bibendum, Sed sollicitudin enim eleifend sodales imperdiet consectetur non urna. Dolor nunc risus elit dignissim nulla elit ligula consequat. Convallis phasellus hendrerit pharetra sit sit. Venenatis blandit pharetra mauris ultrices: Varius sit placerat accumsan lacinia nam laoreet odio eleifend arcu non lacinia, Vitae in non nunc nulla? Et commodo dui vivamus nunc vel magna purus? Imperdiet eu amet nulla bibendum.</p>\n\n<p>Vestibulum lacinia consequat sapien sit malesuada at cursus nec amet ut. Lorem convallis urna hendrerit aenean sapien. Imperdiet risus molestie sodales tincidunt arcu at interdum luctus! Elementum enim pharetra risus quis. Donec venenatis pretium adipiscing sollicitudin lacinia consectetur: Convallis tellus volutpat augue convallis eu consequat bibendum sed. Romanus eunt domus. Nulla non rutrum lorem aenean arcu arcu vestibulum ante quis pharetra phasellus; Arcu quis mi lorem quis quisque; Porta sagittis sit in hendrerit adipiscing! Mauris non est curabitur vitae mollis donec erat cras lacus:</p>\n\n<p>Id rhoncus ultrices massa nibh dolor. Pretium enim amet interdum accumsan est fermentum vel consequat neque dolor amet! Lectus iaculis lobortis risus nam tincidunt eleifend porttitor est eleifend hendrerit lectus? Gravida leo nunc enim faucibus velit lacus dolor augue purus nisi? Est augue at consequat donec aliquet, Laoreet nec aliquam feugiat dis lacus turpis dui: Mauris neque bibendum quis libero dictum consectetur elit dolor turpis. Pretium ac curabitur tristique rutrum congue libero massa gravida non. Felis lobortis ac a id fusce dis tincidunt non amet sagittis elementum? Ut lectus eget at enim vitae nulla est. Metus eget nec rhoncus neque nisl condimentum lacus faucibus augue lacus placera.</p>\n', '0000-00-00 00:00:00', '2013-01-06 12:46:12', '', 1, 1);
INSERT INTO `bliss_posts` VALUES(19, 0, 0, 'Att göra', NULL, '<ul>\n	<li>Kunna visa inneh&aring;ll</li>\n	<li>Bygg p&aring; nya databasmodellen f&ouml;r <em>content</em></li>\n	<li>Najs!</li>\n</ul>\n', '0000-00-00 00:00:00', '2013-01-06 21:05:29', '', 19, 1);
INSERT INTO `bliss_posts` VALUES(20, 0, 0, 'Nytt innehåll igen...', NULL, '<p>Testar s&aring; att det funkar fortfarande.</p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(24, 0, 1, 'Lorem2', NULL, '<p>Hepp?&nbsp;</p>\n\n<p>In blandit porta luctus dui accumsan eget aliquam sed sed; Gravida ipsum mauris elit quam non sed? Eu amet a mauris sem hendrerit consequat eros sit. Ipsum vitae ligula tincidunt sit eget purus porta. Amet leo mauris faucibus dolor pulvinar. Amet neque interdum arcu cras orci. Magna rhoncus massa nam vel varius? Tristique pulvinar at dignissim lacus placerat maecenas nec sed leo: Accumsan amet felis tortor phasellus: Urna arcu massa eget purus ipsum nunc euismod dignissim vitae non.</p>\n\n<p>Consectetur erat sit nunc quis elementum ipsum phasellus. Odio nec nunc eget lacinia at ullamcorper sed? Nulla porta curabitur ut nec diam erat penatibus sed mattis tristique. Mus dui porttitor ligula adipiscing imperdiet. Metus donec risus proin iaculis. Dignissim non vivamus diam dignissim lacus: Nec non rhoncus sociis fermentum nibh dui vel libero, Lorem eget tincidunt nec rutrum turpis cras faucibus.</p>\n\n<p>Est dolor urna at quis placerat? Ipsum rutrum ipsum luctus commodo metus. Est eu sed lacus urna ultricies bibendum nunc donec risus pellentesque: Non amet eleifend neque dui. Phasellus est phasellus tempor elementum accumsan sed vitae luctus, A pharetra quis purus aliquam nec ante vitae fermentum suscipit. Lectus a diam neque vitae lacus tincidunt sit nunc dis lacus: Bibendum phasellus ligula ipsum posuere maecenas adipiscing.</p>\n\n<p>Pharetra porta eget lorem non risus vivamus; Nisi fermentum at facilisis sed varius dictum ligula. Quis amet neque neque non massa nibh! Risus purus vitae rhoncus massa lacus ut! Nam justo feugiat blandit faucibus nisi purus congue aliquet purus suspendisse sodales! Sed mi leo sagittis nulla pharetra sit non volutpat. Augue non faucibus sodales tincidunt; Interdum nulla id lacinia hendrerit mollis imperdiet ante. Ullamcorper ut amet fermentum eget etiam sit,</p>\n\n<p>Proin nulla imperdiet justo accumsan consequat sem cursus. Lacus arcu ligula justo luctus metus lacinia ullamcorper aenean et pharetra neque, Dui adipiscing posuere sit felis urna sit dolor. Eros sodales eleifend venenatis sociis: Ut elit mauris mus faucibus interdum rhoncus, Odio vel mauris sit varius vitae. Cursus amet urna risus rutrum vivamus varius eu neque nam vestibulum molestie. Tincidunt mus mollis hendrerit amet lacus eu: Ac adipiscing consequat libero proin sapien dictum dignissim. Enim convallis eget adipiscing lacus luctus: Tristique est a convallis velit tellus facilisis malesuada purus porta. Eu magna sit leo nam luctus lacus. At etiam luctus luctus pharetra leo a fermentum.</p>\n', '0000-00-00 00:00:00', '2013-01-06 12:43:46', '', 1, 1);
INSERT INTO `bliss_posts` VALUES(25, 0, 0, 'Snart pizza?', NULL, '<p>Condimentum consectetur cursus ut dui; Dui nisl nunc egestas id ipsum neque. Quis lorem sit nisl gravida convallis ipsum; Luctus velit justo at tellus sagittis tellus bibendum, Pharetra aliquam turpis aenean tincidunt tincidunt in parturient iaculis, At tristique mauris tellus non risus pharetra neque, Eros nisl neque et dolor adipiscing nisi dui eros aliquam nascetur dictum. Fermentum eget massa leo quisque risus! Mi urna mauris ut nec non suspendisse. At nec non lectus elementum massa: Consequat phasellus dui rutrum vestibulum; Donec odio vel cursus montes.</p>\n\n<p>Aliquam rutrum phasellus non morbi pulvinar. Nisl ultrices porta velit volutpat nec ut curabitur dolor bibendum viverra. Enim pellentesque vel sodales urna erat mollis metus aliquam varius: Ligula mauris tortor dolor interdum tortor in vitae justo: Leo suscipit facilisis hendrerit elit eget orci; Bibendum massa sed nulla nibh eget vestibulum consequat non cras suspendisse. Suspendisse interdum nisl enim donec viverra porttitor. Leo elit ante duis facilisis risus eu accumsan urna pretium felis urna. Tellus pulvinar enim risus dui sit aliquam erat justo imperdiet arcu pretium? Nunc nec nunc erat rutrum turpis dui? Curabitur accumsan id sed ligula sed mauris mauris donec erat amet; At eget rutrum vitae donec volutpat fermentum.</p>\n\n<p>Nec enim lorem interdum a tellus risus sit varius fusce erat: Risus sit nunc pulvinar id tincidunt orci donec facilisis. Erat amet iaculis fermentum erat duis eu, At lacus sit sit consequat urna placerat hendrerit aenean aliquam! Integer nisi libero augue feugiat risus nisl blandit eget justo sapien condimentum. Gravida enim nullam sit mauris cursus est enim mollis sit dui dolor; Nec tincidunt ut vel adipiscing non in donec suspendisse dignissim phasellus. Rutrum leo urna fermentum in cras et hendrerit nullam quis ut pretium. Urna pulvinar amet convallis convallis eu;</p>\n\n<p>Leo tincidunt tincidunt placerat sed odio quis in; Enim phasellus enim sit lectus; Pulvinar lectus ullamcorper fermentum congue dolor neque cras aliquam dui nisl? Eleifend leo luctus non nec aliquam. Arcu est tortor erat purus donec hendrerit. Erat nec phasellus posuere imperdiet leo sociis: Luctus quis lacus id bibendum. Velit eu convallis leo amet phasellus at: Laoreet dignissim nisl est sed auctor dignissim lacus ac consectetur. Mauris feugiat nec in donec vitae non nisl lacinia erat? Turpis varius mattis ipsum donec nec: Sed quis pretium id rhoncus.</p>\n', '0000-00-00 00:00:00', NULL, 'atet', 1, 1);
INSERT INTO `bliss_posts` VALUES(26, 0, 2, 'Woho!', NULL, '<p>Nu du!</p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(27, 0, 6, 'Nice job!', NULL, '<p>Woot!</p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(28, 0, 1, 'Gå och lägg dig!', NULL, '<p><strong>Borsta nu!!</strong></p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(29, 0, 1, 'Woho!', NULL, '<p>&Auml;t middag nu! Eller laga den f&ouml;rst i alla fall...</p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(30, 0, 1, 'asdf', NULL, '<p>asdf</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(31, 0, 1, 'Yqy!', NULL, '<p>1asdfasdfasdf</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(32, 0, 3, '3', NULL, '<p>tre och s&aring;...</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(33, 0, 6, '6', NULL, '<p>asdfasdfasd fasfdasfasf</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(34, 0, 3, 'Gå och titta på TV nu', NULL, '<p>Ja, g&ouml;r det NU!</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(35, 0, 1, 'Wonkar!', NULL, '', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(36, 0, 1, 'TV', NULL, '', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(37, 0, 1, 'NU!', NULL, '', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(38, 0, 6, 'Album', NULL, '<p>AlbumAlbumAlbumAlbumAlbum</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(39, 0, 1, 'Nu gick vi!', NULL, '', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(40, 0, 3, 'Flugjävel', NULL, '<p>Vel eu nunc donec id sagittis venenatis suspendisse? Erat tristique gravida donec dolor nulla, Lacinia sed nullam convallis vitae aliquet sit sit. Mus sed iaculis porttitor et pretium aliquet. Convallis egestas dictum nulla purus urna arcu sed sit! Nec ligula nam iaculis egestas faucibus at; Id convallis porta consectetur ut pellentesque eleifend vitae.</p>\n\n<p>Ligula risus eu gravida sit elementum porta porta tincidunt: Ut semper iaculis tincidunt porttitor eget nisi metus at turpis. Risus dapibus cursus nunc imperdiet non: Aliquam eget rhoncus nec vestibulum nulla nulla nunc mauris natoque enim dui: Curabitur amet porta rhoncus pharetra dolor molestie! Nulla lorem adipiscing arcu eget in vestibulum pellentesque. Mollis risus vitae accumsan non? Sed nisl nam mauris condimentum vivamus lobortis vitae risus malesuada. Neque nisl non est velit suscipit ut augue vitae tristique lacinia: Tempor fermentum facilisis mauris mi! Accumsan justo fringilla proin sit consectetur venenatis rhoncus orci sit interdum.</p>\n\n<p>A enim arcu sit sollicitudin leo; Mattis commodo non sit imperdiet eu hendrerit quam et cras orci nulla. Est mauris dictum venenatis aliquam pretium eget tincidunt purus id. Ligula volutpat aliquam eu lacus eu. Tincidunt urna dignissim nulla pellentesque: Rutrum dignissim euismod nullam amet metus eleifend dolor id donec, Pharetra laoreet mattis rutrum nec ligula erat facilisis luctus lorem! Justo proin eget curabitur eu cursus tincidunt libero! Consequat integer sed dolor eros id urna. Arcu risus velit euismod est nulla; Natoque ligula lectus nullam bibendum sodales phasellus!</p>\n\n<p>Eleifend est mauris viverra nisl commodo. Enim nec nec sit sem tortor integer, Eros id erat odio dui imperdiet? Nam penatibus erat placerat tincidunt pellentesque tempor? Eget ullamcorper etiam lacinia et non sagittis amet. Fermentum sed fermentum bibendum consectetur tellus duis. Cursus euismod phasellus pharetra aenean aliquam dui varius. Ipsum ullamcorper eu nam ut.</p>\n\n<p>Sit lobortis arcu integer tincidunt sed eros iaculis pretium semper, Luctus dictum vel metus cras et massa metus. Nec suspendisse odio consectetur nulla metus? Luctus risus nec porta nulla iaculis metus eu lorem cursus, Tincidunt felis eget a tellus vitae porta consectetur. Erat et imperdiet pulvinar a pellentesque neque non lacinia nunc lectus ullamcorper. Ut pretium luctus curabitur nibh urna amet lorem phasellus dictum at erat, Amet eu lectus molestie turpis commodo varius dapibus placerat in. Porta eros nisl erat amet augue nunc sed hendrerit! Adipiscing placerat eu vitae nisl volutpat cras tortor! Sodales tristique rhoncus pharetra blandit id.</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(41, 0, 3, 'Some music', NULL, '<p>Fermentum lacus eget dui elit neque mauris blandit blandit nunc mauris phasellus: Nulla dui nec imperdiet volutpat pharetra arcu facilisis; Vel amet interdum porta tellus; Urna sodales non dui proin mauris morbi? Consequat blandit hendrerit nec eget porta nec congue aenean blandit ante. Vitae pulvinar vivamus lacus tincidunt duis. Hendrerit elit aliquam in varius phasellus amet,</p>\n\n<p>Est sem venenatis sapien lacus nec quisque ridiculus urna mauris nam. Pellentesque sed ut phasellus egestas adipiscing maecenas pretium dui; Sed vehicula ultrices nec mauris est justo donec condimentum phasellus! Amet hendrerit sapien vitae cursus convallis vehicula! Arcu neque laoreet luctus porta. Tellus ante curabitur massa amet quis sit. Duis eu massa consectetur luctus posuere quis pretium vel dolor; Odio mus ipsum turpis et, Nec eu lacus bibendum proin curabitur ligula hendrerit consectetur pharetra donec lorem? Malesuada lacus amet nec nisl nec mauris mi non eu nec.</p>\n\n<p>Vitae risus morbi sodales facilisis luctus egestas blandit porta in ridiculus? Est volutpat sit libero lectus enim nunc est eu libero ipsum vivamus. Luctus purus at dignissim risus at nisl: Adipiscing at dolor vehicula lacus erat maecenas! Dui convallis lorem imperdiet ipsum morbi. Neque in sapien purus auctor eget. Turpis natoque commodo eu venenatis parturient dapibus in. Suscipit sed lobortis etiam sed. Fringilla nullam eleifend non condimentum ut quis. Hendrerit massa erat accumsan tincidunt. Ligula vitae at pharetra at odio ipsum! Vitae ut fermentum ultrices non. Tristique pharetra erat ut euismod est nunc lectus sit! At nibh vel amet varius purus: Romanus eunt domus.</p>\n\n<p>Aliquam erat porta sit erat; Bibendum nec etiam elit tincidunt ut convallis velit convallis varius congue sollicitudin. Egestas tincidunt sagittis mus aliquam. Sagittis rutrum lacus enim porta libero. Pretium phasellus dolor proin tincidunt nulla; Sit et enim malesuada dignissim sollicitudin feugiat enim sapien quis sollicitudin urna; Etiam non dui turpis id sapien justo ipsum turpis odio laoreet pretium: Arcu et ipsum rhoncus viverra ut nulla nunc pharetra non dolor. A posuere sociis facilisis pretium lorem integer nec non eu nullam. Vestibulum sed blandit amet facilisis tincidunt mauris nulla ultrices iaculis ultrices: Sed velit nulla erat in sit ipsum? Tempor sapien augue ultrices dolor erat sed sit nisl facilisis. Sollicitudin sagittis eu neque sagittis turpis consectetur id in. Lacus nec in vel ligula ligula eu nullam massa quis blandit dapibus. Gravida vel ipsum dignissim quam.</p>\n\n<p>Magna risus in at rutrum eget vitae justo quis donec. Nec dignissim porta urna placerat. Augue hendrerit at hendrerit diam sed sit a et sollicitudin aenean? Diam gravida porta nec rutrum facilisis arcu parturient! Sed eget ut id posuere at egestas sed lacinia fermentum. Amet donec nisi dui luctus consequat aliquet aenean magna vitae vestibulum enim; Commodo a amet nam risus sodales lorem. Vestibulum dolor ut ut feugiat suscipit consectetur pharetra eros nunc dui urna.</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(42, 0, 3, 'Woohoot!', NULL, '<p>G&aring; och titta p&aring; TV NU!</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 0);
INSERT INTO `bliss_posts` VALUES(43, 0, 6, 'Fredag idag!', NULL, '<p>Suscipit pharetra interdum eget nam lectus dapibus condimentum aliquam fermentum: Dui non risus nec eget facilisis nisl nec parturient. Convallis consequat a porta donec varius nec nulla quis. Pulvinar augue mus pretium ipsum porta elementum sapien nulla! Fringilla malesuada nisl lacus vivamus quam felis ut vivamus diam. Risus nec ut suscipit convallis eget sed dictum lorem sit iaculis. Urna sagittis blandit erat etiam arcu augue rhoncus pellentesque vestibulum nisl. Enim feugiat pretium lacus lacus at elementum. At ipsum erat massa cursus consectetur vestibulum vitae venenatis.</p>\n\n<p>Ut tincidunt non egestas phasellus. Erat neque justo commodo dui orci cursus vestibulum nec nulla eget. Eu leo suspendisse gravida ultricies tristique feugiat augue blandit accumsan. Fermentum sapien congue faucibus mi suspendisse viverra posuere dictum eget. Dui neque aenean gravida eu eu donec augue fermentum amet, Vitae sollicitudin bibendum sollicitudin aenean. Nec hendrerit viverra interdum cursus laoreet?</p>\n\n<p>Urna lorem aliquam lacinia eu non convallis blandit egestas adipiscing purus; Velit eu fermentum eu sodales cursus eget. Arcu hendrerit placerat mattis non ipsum et amet, Elementum egestas ligula iaculis gravida est velit ligula nulla. Nulla accumsan lacus adipiscing donec eleifend fringilla risus porta. Felis augue facilisis dolor hendrerit nulla sit ipsum. Arcu eros nisl ullamcorper velit varius tellus? Parturient venenatis nunc ullamcorper eu ligula cras est ut sed dignissim; Erat dignissim eget eget consectetur facilisis at at imperdiet. Leo sapien id non elementum consectetur erat molestie condimentum egestas. Tempor nunc nunc volutpat tristique felis dictum volutpat. Amet a id interdum placerat neque curabitur nulla parturient? Vitae justo eget malesuada facilisis arcu adipiscing ut interdum vitae ligula! Facilisis elit molestie tempor libero eu vestibulum donec venenatis felis mi proin;</p>\n\n<p>Phasellus sit accumsan vitae erat donec turpis, Venenatis tellus tempor blandit aliquet ligula vel non. Nec lectus luctus iaculis ultricies gravida convallis sed rhoncus sit justo imperdiet. Lacus lorem semper hendrerit eu amet enim feugiat. Aliquet tincidunt suscipit sem pharetra eget a ac; Bibendum laoreet sodales vehicula accumsan euismod nullam faucibus arcu fermentum! Quisque leo suscipit lectus lacus tellus curabitur non consequat amet. Sem nec elementum nullam ligula vitae amet montes sit arcu sociis. Vitae imperdiet ut diam sit rutrum. Nec est suspendisse facilisis nulla quis nunc pharetra lobortis porta. Mattis felis in aliquet nulla fermentum tincidunt condimentum! Risus sagittis eget non mauris cursus fringilla.</p>\n\n<p>Romanus eunt domus. Quis in enim non aenean sit dolor porta est, Non varius faucibus nunc tincidunt vivamus dolor vitae? Quis orci hendrerit blandit enim ante erat facilisis: Sed elementum eget ut leo duis leo, Pretium quis auctor egestas aliquam at egestas nisl non turpis. Nec malesuada hendrerit eu convallis aliquam non elementum volutpat metus. Commodo nulla sapien non lacinia a consequat urna vel nisl hendrerit nibh? Convallis neque pharetra tellus duis amet interdum. Arcu erat pharetra mollis id sapien! Sed non eros nec non! Tortor urna venenatis amet fermentum. Bibendum placerat dolor quis justo augue tempor phasellus quam at lorem ligula. Sit a convallis est eget nec libero metus sagittis.</p>\n', '0000-00-00 00:00:00', NULL, '', 0, 1);
INSERT INTO `bliss_posts` VALUES(44, 0, 7, 'Foux de Fa fa!', NULL, '<p>Foux de Fa fa!Foux de Fa fa!Foux de Fa fa!Foux de Fa fa!<strong><em>Foux de Fa fa!</em></strong>Foux de Fa fa!Foux de Fa fa!Foux de Fa fa!</p>\n\n<p>Fupp!</p>\n', '0000-00-00 00:00:00', '2013-01-07 20:10:02', '', 20, 1);
INSERT INTO `bliss_posts` VALUES(46, 0, 6, 'Nurgle!', NULL, '<p>asdfasfd</p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(47, 0, 1, 'Farglecass!', NULL, '<p style="font-size: 13px;">Farglecass!&nbsp;</p>\n\n<p style="font-size: 13px;">Eget commodo amet pretium curabitur; Tincidunt eros at hendrerit dolor elit erat dui facilisis! Romani ite domum. Lectus erat sed id rutrum sed vestibulum vel. Eu pharetra eleifend ligula eros eu augue: Vitae lorem eu pretium erat. Nulla vel iaculis vitae vivamus integer at. Erat non egestas erat amet aliquam. Eros nunc aliquam eu sed fusce aliquam, Feugiat mauris rutrum est donec congue sociis aenean cursus bibendum mollis mi! Nec eleifend sit convallis eu tincidunt suscipit eget lorem dui consectetur, Sit posuere suspendisse aliquam vehicula porta ut dui eget tellus.</p>\n\n<p style="font-size: 13px;">Sagittis auctor consectetur nec vitae risus. Etiam sociis facilisis fermentum lobortis: Mauris purus blandit venenatis phasellus vitae. Nisl quisque convallis fermentum tristique lacinia sodales erat risus nulla. Sit nisl ut neque dolor pretium blandit nullam turpis sed dolor vitae; Malesuada blandit eget justo sagittis est pharetra nullam convallis lacus phasellus eget; Turpis sit sodales non felis est non tincidunt arcu blandit eget at; Placerat nec purus penatibus non! Risus aenean donec sagittis diam proin sit!</p>\n\n<p style="font-size: 13px;">Vitae phasellus mus erat venenatis varius in eu purus aliquam consequat tellus. Dapibus lorem ut elit eget phasellus dis ut tincidunt? Leo porta consequat sodales erat risus volutpat! Tellus elementum arcu facilisis non penatibus nulla. Sem sed eget nec sit lacus. Nulla nullam sollicitudin ligula fermentum dolor a risus varius justo justo. Est aenean urna hendrerit sed ligula vestibulum. Mauris convallis nibh sodales non venenatis, Lectus quam pharetra nec dui dolor donec elit. Nulla at diam enim nulla vitae erat mattis cras; Phasellus neque dui sit nibh est. Rutrum nec gravida vivamus felis dictum eu pulvinar non? Eget rutrum proin hendrerit mauris neque gravida viverra vitae nisl sollicitudin iaculis.</p>\n\n<p style="font-size: 13px;">Curabitur neque elit odio cursus. Non hendrerit ridiculus pretium cras tincidunt nisl diam vivamus, Pellentesque nisl facilisis at donec at leo tincidunt nec ullamcorper varius. Sit suscipit dictum purus nisl amet metus. Neque nam sit ultrices quis eget. Quis odio ultrices eleifend arcu cras, Semper nec augue phasellus hendrerit dui elit; Interdum lacus faucibus nec id blandit nec erat justo libero condimentum? Suscipit a et semper metus dapibus posuere amet. Sagittis vestibulum blandit placerat sodales pulvinar volutpat nulla curabitur malesuada nunc, Luctus eget vel lorem sit porta; Et eu vel rhoncus erat!</p>\n', '0000-00-00 00:00:00', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(48, 0, 1, 'En ny sak', NULL, '<p>WEho!</p>\n', '2013-01-05 19:54:43', '2013-01-05 19:56:26', '', 1, 0);
INSERT INTO `bliss_posts` VALUES(49, 0, 1, 'Ytterligare en ny sak', NULL, '<p>Nunc mauris sapien rutrum quis mus erat, Malesuada cras elit erat ligula. Ligula in facilisis donec luctus risus ligula. Non tempor ut ipsum id ipsum eget tincidunt venenatis vivamus sed risus. Erat non suspendisse dui non consectetur. Hendrerit congue augue aenean donec nisi! Eget semper semper montes rutrum nec nunc aliquet massa vel. Curabitur donec mi in penatibus. In bibendum dignissim vitae venenatis eu mattis dolor nec in. Non luctus sit quis et accumsan. Elit phasellus fringilla tellus commodo vitae metus bibendum ultricies? Curabitur morbi sit non eget ullamcorper leo risus tristique;</p>\n\n<p>Convallis sed risus arcu nibh nulla adipiscing mauris tincidunt gravida rhoncus mollis. At purus neque vivamus risus dictum; Aliquet hendrerit purus congue sed tincidunt augue! Eu facilisis at ipsum arcu ut donec neque vestibulum molestie: Placerat rutrum vel nunc vestibulum in urna pharetra vel. Accumsan est mi elit risus dui quis nunc ut. Eu dolor nisi facilisis dolor imperdiet in eget pretium lacinia dolor; Fusce porttitor neque etiam aenean viverra hendrerit etiam;</p>\n\n<p>Urna eget felis sed arcu at accumsan eu vitae augue blandit. Bibendum phasellus odio dui sit: Pretium elit tincidunt nulla sed in iaculis malesuada posuere. Arcu nunc facilisis viverra nec commodo nec? Urna urna at hendrerit turpis etiam lorem. Porta lacus varius pharetra malesuada eget! Adipiscing neque ultrices ligula penatibus proin lacus lacus turpis massa, Leo eget vivamus lorem dui vivamus rutrum vel massa posuere volutpat nunc. Viverra lacus est lorem vitae dui eget vitae accumsan consectetur pellentesque. Rutrum neque ut massa gravida magnis ligula pharetra! Lectus risus egestas risus aliquam pellentesque turpis nam cursus. Romanus eunt domus. Massa dignissim ligula vitae lobortis neque amet fusce sed eget imperdiet gravida: Mauris aliquet vitae bibendum vitae mollis. Etiam dui varius massa dui malesuada lacus arcu phasellus purus.</p>\n\n<p>Lacus eget eu phasellus integer. Odio ligula pretium erat risus fermentum varius sit? Dui consectetur amet eu bibendum nec malesuada imperdiet id. Urna dictum amet vitae nec. Sodales neque sem luctus turpis dolor dui mauris sed facilisis. Pretium hendrerit nunc eget vel interdum urna nulla non. Lacus sapien et nunc et dui cum ipsum neque. Integer gravida nulla pulvinar luctus neque cum donec bibendum venenatis; Tincidunt eget at vivamus amet enim. Hendrerit ut consectetur libero pretium placerat! Facilisis rhoncus dis cursus dui maecenas risus eu semper eros. Tortor nec ut lobortis mollis blandit nec nisl. Nullam enim bibendum neque dapibus! In duis aenean nisl enim pharetra porta volutpat!</p>\n\n<p>Fusce vehicula cras risus ipsum iaculis aliquet sodales nec aliquam, Sagittis nec eget ultrices rhoncus cras in nulla suspendisse interdum: Fermentum augue erat sagittis ac volutpat aliquam metus; Tincidunt vestibulum quis nam mollis accumsan phasellus eget volutpat sed eget? Phasellus sed sapien interdum gravida nisl? Eu eget aenean laoreet nunc dui blandit. Donec aenean vitae elit sed! Purus porta non nunc porta nam imperdiet egestas consectetur hendrerit dignissim; In venenatis fusce lacinia fusce urna.</p>\n', '2013-01-05 19:58:10', '2013-01-05 19:58:44', '', 1, 0);
INSERT INTO `bliss_posts` VALUES(50, 0, 6, 'Detta är ett nytt album', NULL, '<p>Consectetur faucibus adipiscing gravida etiam lacus sit magnis. Lacus amet semper sociis a ligula ultricies aenean; Neque vitae odio dolor sollicitudin sapien malesuada sed quis purus auctor? Cum in rutrum ligula sed felis nec amet vel. Mus dui sit amet pretium ligula nam dapibus eget eu justo? Sit aliquam at elit metus varius ut ligula duis sed: Sagittis integer volutpat pellentesque consequat. Ipsum pellentesque dignissim massa phasellus in vel nec, Convallis neque nam dapibus aliquam auctor aenean facilisis: Purus tincidunt tempor sit vivamus aenean nulla urna! Ut consectetur orci est consequat accumsan. Varius vestibulum curabitur pulvinar eu amet adipiscing erat vivamus. Nisl nulla mauris nullam nunc iaculis hendrerit nunc imperdiet urna lacinia purus. Sagittis consectetur at hendrerit pellentesque nulla nulla rhoncus sodales maecenas.</p>\n\n<p>Eget sed sagittis a enim facilisis vitae lectus eu, Risus sapien eget tortor ligula sit urna posuere vivamus eget eros curabitur? Gravida a porta bibendum varius aliquam non tincidunt amet varius? Tincidunt eu lacus risus dignissim id montes. Lacinia orci eu facilisis leo donec est non dui purus eleifend pretium. Enim sapien metus enim lectus facilisis mollis. Non consequat amet blandit metus egestas nec gravida tincidunt est rutrum. Adipiscing sagittis vel viverra elit non imperdiet pellentesque. Orci placerat lacus dolor enim vitae est!</p>\n\n<p>Adipiscing in elit facilisis nec tellus montes convallis sodales. A fringilla nulla eget sollicitudin facilisis: Vel enim cras lorem mattis at porta lacus posuere tincidunt consequat hendrerit. Sit id lacus purus a maecenas sodales vitae eu eleifend. Ipsum nam pellentesque metus ut maecenas sit vitae rutrum quis dui eu. Phasellus arcu eu metus congue at iaculis? Ut lectus amet massa porta ipsum vel. A dictum malesuada ut pellentesque, Risus sed at facilisis viverra cras tincidunt!</p>\n\n<p>Porta congue convallis luctus non est bibendum! Volutpat neque eu nam lacinia leo quam venenatis. Gravida in feugiat lacus faucibus sodales facilisis erat pharetra lorem nibh! Ut bibendum iaculis penatibus malesuada? Nec vestibulum risus pellentesque imperdiet curabitur; Erat pretium eu neque non convallis phasellus? Erat sapien iaculis vestibulum nunc sapien viverra euismod laoreet non eleifend, Tellus eget aliquam placerat est molestie in mauris.</p>\n\n<p>Suspendisse turpis cursus cursus enim nec lorem est quam volutpat erat at. Quis elit ipsum nulla gravida phasellus porta; Et erat erat maecenas eget sapien: Hendrerit quis lacinia convallis feugiat sem? Laoreet nulla est posuere leo: Lorem phasellus lorem enim tempor non tristique et massa sociis nam. Ullamcorper suscipit sed nulla rhoncus fermentum! Ultrices nec nisi at vitae phasellus lacus mollis rutrum. Tincidunt sit eget venenatis lorem quam non nec.</p>\n', '2013-01-06 13:09:50', NULL, '', 1, 0);
INSERT INTO `bliss_posts` VALUES(51, 0, 1, 'Coolers!', NULL, '<p>Najs!</p>\n', '2013-01-06 14:39:56', NULL, '', 1, 0);
INSERT INTO `bliss_posts` VALUES(52, 0, 1, 'Meh!', NULL, '<p>asfd</p>\n', '2013-01-06 14:40:33', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(53, 0, 3, 'Hmmm2', NULL, '<p>&nbsp;class=&quot;disabled&quot;&nbsp;class=&quot;disabled&quot;&nbsp;class=&quot;disabled&quot;</p>\n', '2013-01-06 14:40:56', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(54, 0, 6, 'Men varför?', NULL, '<p>Var &auml;r alla dom nya?</p>\n', '2013-01-06 14:41:16', NULL, '', 1, 1);
INSERT INTO `bliss_posts` VALUES(55, 0, 3, 'Men ... vad hände sen?', NULL, '<p>Ja, var hamnar dom?</p>\n', '2013-01-06 14:58:56', NULL, '', 1, 0);
INSERT INTO `bliss_posts` VALUES(56, 0, 1, 'Men nu du!', NULL, '<p>Yay!</p>\n', '2013-01-06 15:02:03', NULL, '', 1, 0);
INSERT INTO `bliss_posts` VALUES(57, 0, 1, 'Detta är en ny sida!', NULL, '<p>Woho!</p>\n', '2013-01-06 15:20:15', '2013-01-06 15:20:55', '', 1, 1);
INSERT INTO `bliss_posts` VALUES(58, 0, 1, 'Woot!', NULL, '<ol>\n	<li>Fan du!</li>\n	<li>Yeah!</li>\n</ol>\n', '2013-01-06 18:46:41', NULL, '', 17, 0);
INSERT INTO `bliss_posts` VALUES(59, 0, 1, 'Yeah!', NULL, '<p>asdf</p>\n', '2013-01-06 18:58:49', NULL, '', 17, 0);
INSERT INTO `bliss_posts` VALUES(60, 0, 1, 'Keep', NULL, '<p>asdf</p>\n', '2013-01-06 18:58:59', NULL, '', 17, 0);
INSERT INTO `bliss_posts` VALUES(61, 0, 1, 'aaa', NULL, '<p>aaaa</p>\n', '2013-01-06 18:59:08', NULL, '', 17, 0);
INSERT INTO `bliss_posts` VALUES(62, 0, 1, 'bbb', NULL, '<p>bbbb</p>\n', '2013-01-06 18:59:41', NULL, '', 17, 0);
INSERT INTO `bliss_posts` VALUES(63, 0, 16, 'Fraggelrock!', NULL, '<p>$active_icon</p>\n', '2013-01-06 19:10:55', '2013-01-06 19:11:01', '', 17, 1);
INSERT INTO `bliss_posts` VALUES(64, 0, 3, 'Feeet!', NULL, '<p>Bada nu.</p>\n', '2013-01-06 19:28:01', NULL, '', 17, 1);
INSERT INTO `bliss_posts` VALUES(65, 0, 1, 'Nice!', NULL, '<p>Nu s&aring;!</p>\n', '2013-01-06 19:30:42', '2013-01-06 19:30:51', '', 17, 1);
INSERT INTO `bliss_posts` VALUES(66, 0, 16, 'Oudi!', NULL, '<p>&lt;?php echo __(&quot;All&quot;); ?&gt;</p>\n', '2013-01-06 19:32:10', NULL, '', 17, 0);
INSERT INTO `bliss_posts` VALUES(67, 0, 13, 'asdf', NULL, '<p>asdf</p>\n', '2013-01-06 19:32:20', NULL, '', 17, 0);
INSERT INTO `bliss_posts` VALUES(68, 0, 16, 'På page 2', NULL, '<p>&lt;?php echo __(&quot;All&quot;); ?&gt;</p>\n', '2013-01-06 19:32:45', '2013-01-06 19:32:59', '', 17, 1);
INSERT INTO `bliss_posts` VALUES(69, 0, 16, 'Abbe', NULL, '<p>detta &auml;r bara i content.</p>\n', '2013-01-06 19:34:51', '2013-01-06 21:04:57', '', 19, 1);
INSERT INTO `bliss_posts` VALUES(70, 0, 1, 'Koko Johanasson!', NULL, '<p>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;-&gt;order_by(&#39;title&#39;, &#39;asc&#39;)</p>\n\n<p>&nbsp;</p>\n', '2013-01-06 19:35:25', '2013-01-06 19:35:36', '', 17, 1);
INSERT INTO `bliss_posts` VALUES(71, 0, 1, 'En sida till!', NULL, '<p>Bara s&aring; du vet!</p>\n', '2013-01-06 19:44:45', NULL, '', 18, 1);
INSERT INTO `bliss_posts` VALUES(72, 0, 1, 'AAbnaaab', NULL, '<p>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;echo HTML::anchor(&quot;admin/post&quot;, &quot;&lt;i class=\\&quot;icon-ok\\&quot;&gt;&lt;/i&gt; &quot;.__(&quot;All&quot;));</p>\n\n<p>&nbsp;</p>\n', '2013-01-06 19:45:07', '2013-01-06 19:45:17', '', 18, 1);
INSERT INTO `bliss_posts` VALUES(73, 0, 17, 'En till test', NULL, '<p>Testtypen</p>\n', '2013-01-06 20:43:58', NULL, '', 19, 0);
INSERT INTO `bliss_posts` VALUES(74, 0, 1, 'Starta en blogg om Kohana!', NULL, '<p>Ja, det kan ju vara bra, om inte annat f&ouml;r mig sj&auml;lv f&ouml;r att ha till kodsnuttar.</p>\n', '2013-01-06 21:06:06', '2013-01-06 21:12:04', '', 19, 1);
INSERT INTO `bliss_posts` VALUES(75, 0, 3, 'En till i musik 7 jan', NULL, '<p>En till i musik 7 jan.</p>\n', '2013-01-07 20:16:24', '2013-01-07 20:16:32', '', 20, 1);
INSERT INTO `bliss_posts` VALUES(76, 0, 3, 'A. En på TREAN', NULL, '<p>En p&aring; TREAN</p>\n', '2013-01-07 20:16:51', '2013-01-07 20:17:00', '', 20, 1);
INSERT INTO `bliss_posts` VALUES(77, 0, 1, 'Yay!', NULL, '<h1>L&Ouml;P-TV<br />\n<img alt="" height="269" src="files/pages/570/webbtv-logga.jpg" width="530" /></h1>\n\n<p class="preamble"><br />\nH&auml;r ger vi dig klipp fr&aring;n n&auml;tet g&auml;llande l&ouml;pning till hur du underh&aring;ller din kropp p&aring; gymmet f&ouml;r att h&aring;lla dig stark och frisk. P&aring; denna sida kommer du &auml;ven att kunna se Allt om L&ouml;pnings egna live-s&auml;ndningar fr&aring;n lopp till andra events.&nbsp;Vi uppdaterar dig givetvis via v&aring;ra andra kanaler som <a href="http://twitter.com/alltomlopning" target="_blank">Twitter</a> och <a href="https://www.facebook.com/alltomlopning" target="_blank">Facebook</a> n&auml;r vi har sp&auml;nnande program p&aring; g&aring;ng. Tipsa oss g&auml;rna om bra klipp att l&auml;gga upp h&auml;r:&nbsp;<a href="mailto:tv@alltomlopning.se" target="_blank">TV@alltomlopning.se</a><br />\n<br />\n<br />\n<br />\n<strong>Allt om L&ouml;pning live &amp; stream TV</strong></p>\n', '2013-01-07 21:46:02', '2013-01-09 08:02:51', '', 1, 0);
INSERT INTO `bliss_posts` VALUES(78, 0, 3, 'En på music till 21:51', NULL, '<p>En p&aring; music till 21:51En p&aring; music till 21:51En p&aring; music till 21:51En p&aring; music till 21:51En p&aring; music till 21:51En p&aring; music till 21:51En p&aring; music till 21:51</p>\n', '2013-01-07 21:51:40', NULL, '', 20, 0);
INSERT INTO `bliss_posts` VALUES(79, 0, 18, 'Zombar rulez!', NULL, '<p><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><strong><span style="font-size: 13px;">Zombar rulez!&nbsp;</span></strong><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span><span style="font-size: 13px;">Zombar rulez!&nbsp;</span></p>\n', '2013-01-07 21:55:29', '2013-01-07 21:55:39', '', 20, 1);
INSERT INTO `bliss_posts` VALUES(80, 0, 7, 'En på foux till!', NULL, '<p><span style="font-size: 13px;">Zombar rulez!&nbsp;</span></p>\n', '2013-01-07 22:04:08', NULL, '', 20, 1);
INSERT INTO `bliss_posts` VALUES(81, 0, 7, 'Bing!', NULL, '<p>Bing bong.</p>\n', '2013-01-07 22:04:24', NULL, '', 20, 0);
INSERT INTO `bliss_posts` VALUES(82, 0, 3, 'Musix', NULL, '<p>asdf</p>\n', '2013-01-08 08:04:36', NULL, '', 20, 1);
INSERT INTO `bliss_posts` VALUES(83, 0, 6, 'Anders är kass', NULL, '<p>Anders &auml;r kassAnders &auml;r kassAnders &auml;r kassAnders &auml;r kassAnders &auml;r kassAnders &auml;r kassAnders &auml;r kassAnders &auml;r kass</p>\n', '2013-01-09 08:03:01', NULL, '', 1, 0);
INSERT INTO `bliss_posts` VALUES(84, 0, 6, 'En på album till', NULL, '<p>Lacus nullam risus non ipsum dis; Pretium enim nisi a justo. Fermentum arcu tincidunt ligula nulla consequat amet urna eu eget sit pharetra. Ullamcorper iaculis phasellus elementum risus blandit erat nec elit enim mi mollis; Lacinia odio sed elit ipsum lobortis. Turpis a mauris semper nisl nibh eget lorem consectetur nulla vel. Urna sit erat odio quis rutrum et mi penatibus sociis: Orci a leo a sociis convallis vitae molestie justo cursus mauris! Enim ut dui erat ligula velit sed non phasellus? Lacus nunc risus suscipit ut tristique nulla iaculis orci ipsum pretium odio. Augue ipsum non nascetur amet mollis imperdiet, Nunc lorem laoreet placerat dapibus cursus tellus nec nec magna.</p>\n\n<p>Mus malesuada sed dolor nunc duis. Rutrum fusce tincidunt tellus nec! Non accumsan lacus risus cras vivamus nec at ante erat porta. Id malesuada vestibulum facilisis porta enim nascetur dolor rutrum vel. Cursus mi lectus sit aliquam pretium amet. Donec fusce dignissim nunc urna erat fermentum vestibulum rutrum amet rhoncus eget. Justo mi eleifend venenatis nulla mi arcu? Dolor eros pulvinar aenean hendrerit!</p>\n\n<p>Massa mattis leo cras egestas convallis fringilla nisl nunc penatibus pharetra; Nunc nec quis metus dignissim phasellus eu dolor risus ut ligula eget: Adipiscing dui erat ultrices dignissim nec vitae quis nunc mauris; Semper mauris consectetur proin urna eget eu proin suscipit: Non phasellus et varius blandit non nulla lacus libero? Tempor eget nascetur ut cras; Eget sit eget sapien sagittis bibendum parturient gravida convallis auctor adipiscing. Dui placerat vel ante libero lacinia pellentesque etiam aenean tincidunt odio quam; Eget rutrum id pharetra elit facilisis tortor enim euismod volutpat magna! Sagittis risus non et placerat: Urna phasellus diam phasellus vestibulum ipsum sapien risus mauris elementum dui! Vestibulum mattis risus ut ut venenatis mattis turpis libero. Nec ridiculus eros venenatis neque eros eget sodales nunc mi convallis? Suscipit pharetra donec dictum sagittis:</p>\n\n<p>Donec lectus felis consequat vel. Augue mauris porttitor sapien erat eget non placerat erat adipiscing. Mollis purus lacus porta nulla eu quis convallis eget quis. Non rutrum montes blandit sed neque? Integer vitae cursus dolor neque placerat. Dui eros turpis nam etiam amet quis non pretium. Id sodales aliquam consectetur convallis gravida dolor commodo elementum? Metus aliquam aenean at at nisl gravida amet consectetur.</p>\n', '2013-01-10 07:55:39', NULL, '', 22, 0);
INSERT INTO `bliss_posts` VALUES(85, 0, 18, 'Zweet!', NULL, '<p>Lacus nullam risus non ipsum dis; Pretium enim nisi a justo. Fermentum arcu tincidunt ligula nulla consequat amet urna eu eget sit pharetra. Ullamcorper iaculis phasellus elementum risus blandit erat nec elit enim mi mollis; Lacinia odio sed elit ipsum lobortis. Turpis a mauris semper nisl nibh eget lorem consectetur nulla vel. Urna sit erat odio quis rutrum et mi penatibus sociis: Orci a leo a sociis convallis vitae molestie justo cursus mauris! Enim ut dui erat ligula velit sed non phasellus? Lacus nunc risus suscipit ut tristique nulla iaculis orci ipsum pretium odio. Augue ipsum non nascetur amet mollis imperdiet, Nunc lorem laoreet placerat dapibus cursus tellus nec nec magna.</p>\n\n<p>Mus malesuada sed dolor nunc duis. Rutrum fusce tincidunt tellus nec! Non accumsan lacus risus cras vivamus nec at ante erat porta. Id malesuada vestibulum facilisis porta enim nascetur dolor rutrum vel. Cursus mi lectus sit aliquam pretium amet. Donec fusce dignissim nunc urna erat fermentum vestibulum rutrum amet rhoncus eget. Justo mi eleifend venenatis nulla mi arcu? Dolor eros pulvinar aenean hendrerit!</p>\n\n<p>Massa mattis leo cras egestas convallis fringilla nisl nunc penatibus pharetra; Nunc nec quis metus dignissim phasellus eu dolor risus ut ligula eget: Adipiscing dui erat ultrices dignissim nec vitae quis nunc mauris; Semper mauris consectetur proin urna eget eu proin suscipit: Non phasellus et varius blandit non nulla lacus libero? Tempor eget nascetur ut cras; Eget sit eget sapien sagittis bibendum parturient gravida convallis auctor adipiscing. Dui placerat vel ante libero lacinia pellentesque etiam aenean tincidunt odio quam; Eget rutrum id pharetra elit facilisis tortor enim euismod volutpat magna! Sagittis risus non et placerat: Urna phasellus diam phasellus vestibulum ipsum sapien risus mauris elementum dui! Vestibulum mattis risus ut ut venenatis mattis turpis libero. Nec ridiculus eros venenatis neque eros eget sodales nunc mi convallis? Suscipit pharetra donec dictum sagittis:</p>\n\n<p>Donec lectus felis consequat vel. Augue mauris porttitor sapien erat eget non placerat erat adipiscing. Mollis purus lacus porta nulla eu quis convallis eget quis. Non rutrum montes blandit sed neque? Integer vitae cursus dolor neque placerat. Dui eros turpis nam etiam amet quis non pretium. Id sodales aliquam consectetur convallis gravida dolor commodo elementum? Metus aliquam aenean at at nisl gravida amet consectetur.</p>\n', '2013-01-10 07:56:35', '2013-01-10 07:56:43', '', 22, 1);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_roles`
--

CREATE TABLE `bliss_roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Data i tabell `bliss_roles`
--

INSERT INTO `bliss_roles` VALUES(1, 'login', 'Login privileges, granted after account confirmation');
INSERT INTO `bliss_roles` VALUES(2, 'admin', 'Administrative user, has access to everything.');

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_roles_users`
--

CREATE TABLE `bliss_roles_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data i tabell `bliss_roles_users`
--

INSERT INTO `bliss_roles_users` VALUES(1, 1);
INSERT INTO `bliss_roles_users` VALUES(6, 1);
INSERT INTO `bliss_roles_users` VALUES(7, 1);
INSERT INTO `bliss_roles_users` VALUES(8, 1);
INSERT INTO `bliss_roles_users` VALUES(13, 1);
INSERT INTO `bliss_roles_users` VALUES(14, 1);
INSERT INTO `bliss_roles_users` VALUES(15, 1);
INSERT INTO `bliss_roles_users` VALUES(16, 1);
INSERT INTO `bliss_roles_users` VALUES(17, 1);
INSERT INTO `bliss_roles_users` VALUES(18, 1);
INSERT INTO `bliss_roles_users` VALUES(19, 1);
INSERT INTO `bliss_roles_users` VALUES(20, 1);
INSERT INTO `bliss_roles_users` VALUES(21, 1);
INSERT INTO `bliss_roles_users` VALUES(22, 1);
INSERT INTO `bliss_roles_users` VALUES(23, 1);
INSERT INTO `bliss_roles_users` VALUES(24, 1);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_term_taxonomy`
--

CREATE TABLE `bliss_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Data i tabell `bliss_term_taxonomy`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_types`
--

CREATE TABLE `bliss_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `configuration` text NOT NULL,
  `display` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Data i tabell `bliss_types`
--

INSERT INTO `bliss_types` VALUES(1, 0, 'Page', 'page', NULL, 'Vilka fält som ligger var i ADMIN.', 'Koden för att visa här...');
INSERT INTO `bliss_types` VALUES(3, 0, 'Music', 'music', NULL, '', NULL);
INSERT INTO `bliss_types` VALUES(6, 0, 'Album', 'album', NULL, '', NULL);
INSERT INTO `bliss_types` VALUES(7, 0, 'foux', 'faffa2', NULL, '', NULL);
INSERT INTO `bliss_types` VALUES(13, 0, 'Fraggel2', 'fraggel2', NULL, '', NULL);
INSERT INTO `bliss_types` VALUES(16, 6, 'page2', 'Kuff', NULL, '', NULL);
INSERT INTO `bliss_types` VALUES(17, 1, 'test', 'test', NULL, '', NULL);
INSERT INTO `bliss_types` VALUES(18, 0, 'Zombar', 'zombar', NULL, '', NULL);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_users`
--

CREATE TABLE `bliss_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(127) NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `username_nice` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `salt` varchar(64) NOT NULL,
  `logins` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `activation_key` varchar(64) DEFAULT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`),
  UNIQUE KEY `uniq_username_nice` (`username_nice`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Data i tabell `bliss_users`
--

INSERT INTO `bliss_users` VALUES(1, 'anders@bobolo.se', 'admin', 'admin', '0faf66c33ae7d33fb1ec29a5b8352686e3787d076bcb3a8ae8a12df4dc509663', 'salt', 68, '2013-01-10 08:29:47', NULL, 1);
INSERT INTO `bliss_users` VALUES(6, 'anders.dahlgren@gmail.com', 'member', 'member', '0ad3cd63731dc6804df9e040fa45f6fde7e2e88939370c73ee7d818112af51d3', '', 0, NULL, NULL, 1);
INSERT INTO `bliss_users` VALUES(7, 'anders.dahlgren+1@gmail.com', 'anders', 'anders', '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 2, '2013-01-06 15:21:44', NULL, 1);
INSERT INTO `bliss_users` VALUES(8, 'anders.dahlgren+2@gmail.com', 'Kalle', 'kalle', '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 0, NULL, NULL, 0);
INSERT INTO `bliss_users` VALUES(13, 'anders.dahlgren+3@gmail.com', 'Kalle23', 'kalle23', '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 0, NULL, NULL, 1);
INSERT INTO `bliss_users` VALUES(14, 'anders.dahlgren+4@gmail.com', 'kalle3', 'kalle3', '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 0, NULL, NULL, 1);
INSERT INTO `bliss_users` VALUES(15, 'anders+2@bobolo.se', 'Orvar', 'orvar', '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', 'NzMB1uPRQHZOfsOmSxBGtSWazpshC8iwZHXVLEC08ZNm7qJZJ64Wc1UcOVSBWe97', 0, NULL, NULL, 1);
INSERT INTO `bliss_users` VALUES(16, 'stina@bobolo.se', 'Stina', 'stina', '93950685bae86d5a83298725a0bb16da47de31a6cb859299e3fe39d321e1517c', '', 5, '2013-01-06 18:18:18', NULL, 1);
INSERT INTO `bliss_users` VALUES(17, 'flisa@bobolo.se', 'Flisa', 'flisa', 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'm83ESO2nRdJ1eHpqEKvvTrkYVQbTcNdzX3JySiijvoIiPAPagMJ1FIKwf4g0cwo3', 1, '2013-01-06 18:40:04', NULL, 0);
INSERT INTO `bliss_users` VALUES(18, 'azze@bobolo.se', 'Azzé', 'azze', 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'jA8EkRRNbzftKfDBqiUqw70y0oVBSM3hQGHcyvLb1yfUgGRweikUlcuOhCwmC1TT', 1, '2013-01-06 19:44:27', NULL, 1);
INSERT INTO `bliss_users` VALUES(19, 'anders+3@bobolo.se', 'جستجو · تصاویر', '', 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'L8oO33QmYD3J6GBRaPJE1ff6aIQ5Tl3qt3zxKiM8IDh0Qb4aq9NtHySwWqPk0wAh', 1, '2013-01-06 19:47:24', NULL, 0);
INSERT INTO `bliss_users` VALUES(20, 'anders.dahlgren+5@gmail.com', 'Olle', 'olle', 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'umFtwkftocyJO1qrk5k0U7TtIohwaI8bKEnDhJEdfY0ge3itiwerz5fdLqCSm6OW', 2, '2013-01-09 07:45:37', NULL, 0);
INSERT INTO `bliss_users` VALUES(21, 'info@bobolo.se', 'Sven', 'sven', 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'y1L99JyK7XCefCBMUsjCaaNni3XRKIJLhyALc3Tpf8KRym6FzH7wuLyj6sqbVsmm', 1, '2013-01-09 08:06:44', NULL, 0);
INSERT INTO `bliss_users` VALUES(22, 'anders.dahlgren+6@gmail.com', 'fekal', 'fekal', 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'xTJs0pMT0kJCHQ85PQl0m1vRgSQPhO7F1bDe5lZy0WtPhRyuIQ7wSk8jFRSpaJZ1', 1, '2013-01-09 08:31:59', NULL, 0);
INSERT INTO `bliss_users` VALUES(23, 'anders.dahlgren+123@gmail.com', 'kevin', 'kevin', 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'jLIAZoFXtvZweqg4EIOJfhS9U3T94yvwK2lf2li0lkJFxwtHRSAjh2cNeUXWVzna', 0, NULL, NULL, 0);
INSERT INTO `bliss_users` VALUES(24, 'webmaster@bobolo.se', 'ollekalle', 'ollekalle', 'a74ab46caad8af8280e436adf4f97ba7ecb5eb5469d4aecd8d48fbf3f658e1e9', 'GLK74WjgzWbPOWR8v15zYTlBJP9tgvMUhDIMZAuY7Y2ju0IpH5yYbh4ooVDkWl5L', 0, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Struktur för tabell `bliss_user_tokens`
--

CREATE TABLE `bliss_user_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(40) NOT NULL,
  `type` varchar(100) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Data i tabell `bliss_user_tokens`
--


--
-- Restriktioner för dumpade tabeller
--

--
-- Restriktioner för tabell `bliss_roles_users`
--
ALTER TABLE `bliss_roles_users`
  ADD CONSTRAINT `bliss_roles_users_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `bliss_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bliss_roles_users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `bliss_roles` (`id`) ON DELETE CASCADE;

--
-- Restriktioner för tabell `bliss_user_tokens`
--
ALTER TABLE `bliss_user_tokens`
  ADD CONSTRAINT `bliss_user_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `bliss_users` (`id`) ON DELETE CASCADE;
